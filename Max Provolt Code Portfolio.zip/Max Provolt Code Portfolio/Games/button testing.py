import pygame, os, math, random, time

class Entity(pygame.sprite.Sprite):

    pass

class Button(Entity):

    def __init__(self, x, y, w, h, color, text):

        pygame.sprite.Sprite.__init__(self)

        self.w = w
        self.h = h

        self.color = color

        self.image = pygame.Surface([self.w, self.h])
        self.rect = self.image.get_rect(center = (x, y))

        self.font = pygame.font.Font("freesansbold.ttf", 20)
        self.text = self.font.render(text, True, (128, 128, 128))
        self.textrect = self.text.get_rect(center = self.image.get_rect().center)
        self.rect.center = (screen_width / 2, screen_height / 2)
        self.image.fill(self.color)
        self.image.blit(self.text, self.textrect)

        self.isLeftClick = False
        self.isRightClick = False

    def mouseEvents(self):

        mouse = pygame.mouse.get_pos()
        click = pygame.mouse.get_pressed()

        if self.rect.x + self.w > mouse[0] > self.rect.x:
            if self.y + self.h > mouse[1] > self.rect.y:

                if click[0] == 1 and not self.is_left_click:
                    if not self.is_left_click:
                        self.actionLeft()
                    self.is_left_click = True
                elif click[0] == 0:
                    self.is_left_click = False
                    
                if click[2] == 1:
                    if not self.is_right_click:
                        self.actionRight()
                    self.is_right_click = True
                elif click[2] == 0:
                    self.is_right_click = False

    def actionLeft(self):

        titleScreenInit()

    def actionRight(self):
        
        pass

    def update(self):

        self.mouseEvents()



def titleScreenInit():

    allSprites.kill()
    button = Button(100, 100, 50, 50, "red", "Bruh")

def updateAll():

    allSprites.update()





end_shell = False
total_frames = 0

screen_width = 1920
screen_height = 1080
screen = pygame.display.set_mode((int(screen_width), int(screen_height)))
bg_color = (255, 255, 255)

pygame.init()

pygame.display.set_caption("Button Testing")

fps = 60
clock = pygame.time.Clock()

allSprites = pygame.sprite.Group()
buttons = pygame.sprite.Group()
button = Button(100, 100, 50, 50, "red", "Bruh")
allSprites.add(button)
buttons.add(button)

while not end_shell:

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            end_shell = True

    screen.fill(bg_color)

    updateAll()

    allSprites.draw(screen)

    total_frames += 1

    pygame.display.update()
    clock.tick(fps)

pygame.quit()


