import pygame

class SpriteGroups:
    
    allSprites = pygame.sprite.Group()
    walls = pygame.sprite.Group()
    players = pygame.sprite.Group()
    goals = pygame.sprite.Group()
    buttons = pygame.sprite.Group()
    sliders = pygame.sprite.Group()
    
    rSliderGroup = pygame.sprite.Group()
    gSliderGroup = pygame.sprite.Group()
    bSliderGroup = pygame.sprite.Group()