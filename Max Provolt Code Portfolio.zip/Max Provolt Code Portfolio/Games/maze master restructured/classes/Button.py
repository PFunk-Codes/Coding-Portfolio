import pygame

from classes.Entity import Entity

class Button(Entity):

    def __init__(self, x, y, w, h, action, buttonColor, highlightColor, textColor, fontSize, text):

        pygame.sprite.Sprite.__init__(self)

        self.w = w
        self.h = h

        self.action = action

        self.buttonColor = buttonColor
        self.highlightColor = highlightColor
        self.textColor = textColor
        self.fontSize = fontSize

        self.image = pygame.Surface([self.w, self.h])

        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y

        self.font = pygame.font.Font('freesansbold.ttf', self.fontSize)
        self.text = self.font.render(text, True, self.textColor)
        self.textrect = self.text.get_rect(center = self.image.get_rect().center)
        self.image.fill(self.buttonColor)
        self.image.blit(self.text, self.textrect)

        self.isClicked = False

    def events(self):

        self.mouse = pygame.mouse.get_pos()
        self.buttons = pygame.mouse.get_pressed()
        self.keys = pygame.key.get_pressed()

        if self.getHover():
            
            self.image.fill(self.highlightColor)
            self.image.blit(self.text, self.textrect)
            
            if self.buttons[0] and not self.isClicked:
            
                self.isClicked = True
            
        if not self.getHover():
            
            self.image.fill(self.buttonColor)
            self.image.blit(self.text, self.textrect)
            
            self.isClicked = False
            
        if not self.buttons[0] and self.isClicked:
            
            self.action()
            self.isClicked = False

    def update(self):

        self.events()