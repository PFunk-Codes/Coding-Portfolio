import pygame

class Entity(pygame.sprite.Sprite):

    def update_position(self):

        self.rect.x += self.xVel
        self.rect.y += self.yVel

    def stop_xVel(self):

        self.xVel = 0

    def stop_yVel(self):

        self.yVel = 0

    def stop_vel(self):

        self.stop_xVel()
        self.stop_yVel()
        
    def getHover(self):

        return self.rect.collidepoint(self.mouse)

    def sprite_render(self):

        self.image = pygame.transform.scale((pygame.image.load(self.image_name)), (self.w, self.h))   