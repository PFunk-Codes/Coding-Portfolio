from typing import Counter
import pygame, os, sys

class Constants:
    
    #General gamestate constants
    DIR = os.path.abspath(__file__).replace('classes\Constants.py', '') if sys.platform.startswith('win32') else os.path.abspath(__file__).replace('classes/Constants.py', '') 
    IMG_DIR = DIR + 'images/'
    LVL_DIR = DIR + 'levels/'
    SCREEN_WIDTH = 750
    SCREEN_HEIGHT = 750
    SCREEN = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
    
    #Other miscellaneous gamestate values
    ZOOM = 50
    CURRENT_LVL = 1
    COUNTER = 0
    
    #Settings Menu
    BG_COLOR = [255, 255, 255]
    WALL_COLOR = [128, 128, 128]