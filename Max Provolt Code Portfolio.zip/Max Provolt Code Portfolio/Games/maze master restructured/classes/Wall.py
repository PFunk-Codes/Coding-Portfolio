import pygame

from classes.Entity import Entity
from classes.Constants import Constants

class Wall(Entity):

    def __init__(self, x, y, w, h, lockColor, color = Constants.WALL_COLOR):

        pygame.sprite.Sprite.__init__(self)

        self.w = w
        self.h = h

        self.color = color
        self.lockColor = lockColor

        self.image = pygame.Surface([self.w, self.h])
        self.image.fill(self.color)
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y
        
    def checkColor(self):
        
        self.color = Constants.WALL_COLOR
    
    def update(self):

        if not self.lockColor:
            self.checkColor()
        self.image.fill(self.color)