from classes.Button import Button
from classes.Constants import Constants
from classes.Slider import Slider
from classes.SpriteGroups import SpriteGroups
from classes.Wall import Wall

from functions.GenerateLevel import generateLevel

class ButtonActions:
    
    @staticmethod
    def noAction():pass
    
    @staticmethod
    def clearSprites():
        
        for sprite in SpriteGroups.allSprites:
            sprite.kill()
    
    @staticmethod
    def mainMenu():
        
        ButtonActions.clearSprites()
        
        title = Button(100, 100, 500, 50, ButtonActions.noAction, Constants.BG_COLOR, Constants.BG_COLOR, (0, 0, 0), 18, 'Maze Master')
        startButton = Button(100, 200, 500, 50, ButtonActions.startGame, (128, 128, 128), (64, 64, 64), (0, 0, 0), 18, 'Start Game')
        settingsButton = Button(100, 300, 500, 50, ButtonActions.settingsMenu, (128, 128, 128), (64, 64, 64), (0, 0, 0), 18, 'Settings')
        
        SpriteGroups.allSprites.add((title, startButton, settingsButton))
        SpriteGroups.buttons.add((title, startButton, settingsButton))
    
    @staticmethod
    def startGame():
        
        ButtonActions.clearSprites()
        
        Constants.CURRENT_LVL = 1
        generateLevel(Constants.ZOOM)
        
    @staticmethod
    def finishMenu():
        
        ButtonActions.clearSprites()
        
        restart = Button(100, 100, 500, 50, ButtonActions.startGame, (128, 128, 128), (64, 64, 64), (0, 0, 0), 18, 'Restart')
        mainMenu = Button(100, 200, 500, 50, ButtonActions.mainMenu, (128, 128, 128), (64, 64, 64), (0, 0, 0), 18, 'Main Menu')
        
        SpriteGroups.allSprites.add((restart, mainMenu))
        SpriteGroups.buttons.add((restart, mainMenu))
    
    @staticmethod
    def settingsMenu():
        
        ButtonActions.clearSprites()
        
        mainMenu = Button(100, 100, 500, 50, ButtonActions.mainMenu, (128, 128, 128), (64, 64, 64), (0, 0, 0), 18, 'Main Menu')
        
        colorIndicator = Wall(350, 50, 50, 50, False)
        
        rBack = Wall(100, 200, 50, 200, True, (64, 48, 48))
        gBack = Wall(200, 200, 50, 200, True, (48, 64, 48))
        bBack = Wall(300, 200, 50, 200, True, (48, 48, 64))
        
        rSlider = Slider(100, 200, 400, Constants.WALL_COLOR[0] / 255, 50, 50, (128, 128, 128))
        gSlider = Slider(200, 200, 400, Constants.WALL_COLOR[1] / 255, 50, 50, (128, 128, 128))
        bSlider = Slider(300, 200, 400, Constants.WALL_COLOR[2] / 255, 50, 50, (128, 128, 128))
        
        SpriteGroups.allSprites.add((mainMenu, colorIndicator, rBack, gBack, bBack, rSlider, gSlider, bSlider))
        SpriteGroups.walls.add((colorIndicator, rBack, gBack, bBack))
        SpriteGroups.buttons.add(mainMenu)
        SpriteGroups.sliders.add((rSlider, gSlider, bSlider))
        SpriteGroups.rSliderGroup.add(rSlider)
        SpriteGroups.gSliderGroup.add(gSlider)
        SpriteGroups.bSliderGroup.add(bSlider)