import pygame

from classes.Constants import Constants
from classes.Entity import Entity

class Player(Entity):

    def __init__(self, xPos, yPos, w, h, file):

        pygame.sprite.Sprite.__init__(self)

        self.w = w
        self.h = h

        self.xPos = xPos
        self.yPos = yPos

        self.color = (255, 255, 255)
        self.file = file

        self.image = pygame.Surface([self.w, self.h])
        self.image_name = Constants.IMG_DIR + self.file + "render.png"

        self.rect = self.image.get_rect()
        self.rect.x = self.xPos
        self.rect.y = self.yPos

        self.xVel = 0
        self.yVel = 0
        self.speed = (4 / 25) * Constants.ZOOM

    def prev_pos(self):

        self.prev_xPos = self.rect.x
        self.prev_yPos = self.rect.y

    def events(self):

        self.keys = pygame.key.get_pressed()
 
        self.movements()

    def movements(self):

        if self.keys[pygame.K_RIGHT]:
            self.rect.x += self.speed
        if self.keys[pygame.K_LEFT]:
            self.rect.x -= self.speed
        if self.keys[pygame.K_UP]:
            self.rect.y -= self.speed
        if self.keys[pygame.K_DOWN]:
            self.rect.y += self.speed

    def update(self):

        self.prev_pos()
        self.events()
        self.update_position()
        self.sprite_render()