from classes.Wall import Wall

class Goal(Wall):

    pass