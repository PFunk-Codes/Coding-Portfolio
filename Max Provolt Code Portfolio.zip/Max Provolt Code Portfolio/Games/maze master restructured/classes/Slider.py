import pygame

from classes.SpriteGroups import SpriteGroups
from classes.Wall import Wall

class Slider(Wall):
    
    def __init__(self, x, upperBound, lowerBound, ratio, w, h, color):

        pygame.sprite.Sprite.__init__(self)

        self.w = w
        self.h = h

        self.upperBound = upperBound
        self.lowerBound = lowerBound
        self.ratio = ratio #distance from upperBound in pixels
        
        self.color = color

        self.image = pygame.Surface([self.w, self.h])
        self.image.fill(self.color)

        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.center = [self.rect.center[0], self.lowerBound + ((self.upperBound - self.lowerBound) * self.ratio)]

    def events(self):
        
        self.mouse = pygame.mouse.get_pos()
        self.buttons = pygame.mouse.get_pressed()
        self.keys = pygame.key.get_pressed()
        
        if self.getHover() and self.buttons[0]:
            
            for slider in SpriteGroups.sliders:
                if slider.isClicked and not self == slider:
                    return False #events will return false, skipping setting isClicked to true, because another slider has already been clicked
            self.isClicked = True
            
        if not self.buttons[0]:
            
            self.isClicked = False
            
        if self.isClicked:
            
            self.rect.center = (self.rect.center[0], self.mouse[1])
            
            if self.rect.bottom > self.lowerBound:
                self.rect.bottom = self.lowerBound
            if self.rect.top < self.upperBound:
                self.rect.top = self.upperBound
            
            self.ratio = -(self.rect.bottom - self.lowerBound) / -(self.upperBound - self.lowerBound + self.h)
            
    def update(self):
        
        self.events()