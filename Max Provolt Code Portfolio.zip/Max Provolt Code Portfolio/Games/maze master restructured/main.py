import pygame

from classes.Constants import Constants
from classes.SpriteGroups import SpriteGroups
from classes.ButtonActions import ButtonActions

from functions.UpdateAll import updateAll

end_shell = False
total_frames = 0

pygame.init()

pygame.display.set_caption("Maze Master v2.0")

fps = 60
clock = pygame.time.Clock()

ButtonActions.mainMenu()

while not end_shell:

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            end_shell = True

    Constants.SCREEN.fill(Constants.BG_COLOR)

    updateAll()

    SpriteGroups.allSprites.draw(Constants.SCREEN)

    total_frames += 1

    pygame.display.update()
    clock.tick(fps)

pygame.quit()