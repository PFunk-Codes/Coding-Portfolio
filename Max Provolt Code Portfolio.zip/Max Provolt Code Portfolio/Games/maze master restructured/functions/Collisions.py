import pygame

from classes.Constants import Constants
from classes.SpriteGroups import SpriteGroups

from functions.GenerateLevel import generateLevel

def collisions():

    for player in SpriteGroups.players:
        for wall in SpriteGroups.walls:

            if pygame.sprite.collide_rect(player, wall):

                if player.prev_xPos + player.w <= wall.rect.left:

                  player.rect.x = wall.rect.x - player.w
                  player.stop_xVel()

                if player.prev_xPos >= wall.rect.right:

                  player.rect.x = wall.rect.x + wall.w
                  player.stop_xVel()

                if player.prev_yPos + player.h <= wall.rect.top:

                  player.rect.y = wall.rect.y - player.h
                  player.stop_xVel()

                if player.prev_yPos >= wall.rect.bottom:

                  player.rect.y = wall.rect.y + wall.w
                  player.stop_xVel()

    for player in SpriteGroups.players:
        for goal in SpriteGroups.goals:

            if pygame.sprite.collide_rect(player, goal):

                for sprite in SpriteGroups.allSprites:

                    sprite.kill()

                Constants.CURRENT_LVL += 1

                generateLevel(Constants.ZOOM)