from classes.Constants import Constants
from classes.SpriteGroups import SpriteGroups

def screenRoll():

    for player in SpriteGroups.players:
        xshift = Constants.SCREEN_WIDTH / 2 - player.rect.center[0]
        yshift = Constants.SCREEN_HEIGHT / 2 - player.rect.center[1]
        for sprite in SpriteGroups.allSprites:
            sprite.rect.x += xshift
            sprite.rect.y += yshift