from classes.SpriteGroups import SpriteGroups
from classes.Constants import Constants

from functions.Collisions import collisions
from functions.ScreenRoll import screenRoll
from functions.UpdateSliders import updateSliders

def updateAll():

    updateSliders()
    SpriteGroups.allSprites.update()
    collisions()
    screenRoll()