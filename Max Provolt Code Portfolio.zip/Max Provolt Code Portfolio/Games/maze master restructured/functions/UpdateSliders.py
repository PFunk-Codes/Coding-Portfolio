from classes.Constants import Constants
from classes.SpriteGroups import SpriteGroups

def updateSliders():
    
    if len(SpriteGroups.sliders) == 0:
        return False
    
    for rSlider in SpriteGroups.rSliderGroup:
        Constants.WALL_COLOR[0] = rSlider.ratio * 255
    for gSlider in SpriteGroups.gSliderGroup:
        Constants.WALL_COLOR[1] = gSlider.ratio * 255
    for bSlider in SpriteGroups.bSliderGroup:
        Constants.WALL_COLOR[2] = bSlider.ratio * 255