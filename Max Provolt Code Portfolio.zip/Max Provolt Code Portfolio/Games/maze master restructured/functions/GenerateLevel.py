from classes.Constants import Constants
from classes.Goal import Goal
from classes.Player import Player
from classes.SpriteGroups import SpriteGroups
from classes.Wall import Wall
import classes.ButtonActions

def generateLevel(scale):

    try:
        raw_level = open((Constants.LVL_DIR + "L" + str(Constants.CURRENT_LVL) + ".txt"), "r")
    except FileNotFoundError:
        
        for sprite in SpriteGroups.allSprites:
            sprite.kill()
        classes.ButtonActions.ButtonActions.finishMenu()
        return False

    level = raw_level.readlines()
    raw_level.close()
        
    x = y = 0
    
    for line in level:
        for char in line:
            if char == "W":
                wall = Wall(x, y, scale, scale, False)
                SpriteGroups.walls.add(wall)
                SpriteGroups.allSprites.add(wall)
            elif char == "P":
                player = Player(x, y, int(.75 * scale), int(.75 * scale), "player/")
                SpriteGroups.players.add(player)
                SpriteGroups.allSprites.add(player)
            elif char == "G":
                goal = Goal(x, y, scale, scale, True, (255, 255, 0))
                SpriteGroups.goals.add(goal)
                SpriteGroups.allSprites.add(goal)
            x += scale
        x = 0
        y += scale