This is your guide to creating new levels for this game. If you do not read this, you might not get expected results, although it's not that hard.
This document assumes you are too stupid, lazy, or uneducated to edit the code. However, I, the author, do not assume that. You are perfect just the way you are.

When you name your levels, you must name them like so; L*number*. For instance: L4

Also, you must name them in the order you wish for them to appear in the game. If you have 5 levels, they must go L1, L2, L3, L4, L5.
If you skip a number, then the game will end and return to the main menu when it does not see your number.
If you do not follow this naming convention, the game will ignore all of your levels and end the game. This includes
not having a level file named L1.

In the file, these letters correspond to objects in the level; 

W = Wall
G = Goal
P = Player

All you have to do is type in a plain text .txt file with those 3 letters. Any characters besides these three will be ignored.

No, this text will not be compiled into code. It is only being read character by character.

The game does not check whether the level is possible. So, that's your job.
Unless you don't want it to be possible. In which case... I guess I made this open source for a reason.