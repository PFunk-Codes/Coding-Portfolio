##############################################
##          GRAVITY SIMULATOR V1.0          ##
##                                          ##
##          Written by Max Provolt          ##
##                                          ##
##        A basic gravity simulator.        ##
##         Interactive and modular.         ##
## Feel free to add your own functionality! ##
##############################################

import pygame

from classes.Button import Button
from classes.ButtonActions import ButtonActions
from classes.Constants import Constants
from classes.SpriteGroups import SpriteGroups

from functions.UpdateAll import updateAll

END_SHELL = False
totalFrames = 0

pygame.init()

pygame.display.set_caption('Gravity Simulator v1.0')

fps = 60
clock = pygame.time.Clock()

resetButton = Button(0, 0, 75, 40, ButtonActions.reset, (128, 128, 128), (255, 255, 255), 24, 'Reset') #x, y, w, h, buttonColor, textColor, fontSize, text
setSmallButton = Button(100, 0, 175, 40, ButtonActions.setSmallBody, (128, 128, 128), (255, 255, 255), 24, 'Small Planet')
setMediumButton = Button(300, 0, 175, 40, ButtonActions.setMediumBody, (128, 128, 128), (255, 255, 255), 24, 'Medium Planet')
setLargeButton = Button(500, 0, 175, 40, ButtonActions.setLargeBody, (128, 128, 128), (255, 255, 255), 24, 'Large Planet')

SpriteGroups.allSprites.add((resetButton, setSmallButton, setMediumButton, setLargeButton))
SpriteGroups.buttons.add((resetButton, setSmallButton, setMediumButton, setLargeButton))
#suns.add(Sun)

while not END_SHELL:

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            END_SHELL = True

    Constants.SCREEN.fill(Constants.BG_COLOR)

    updateAll()
    
    SpriteGroups.allSprites.draw(Constants.SCREEN)

    totalFrames += 1

    pygame.display.update()
    clock.tick(fps)

pygame.quit()

