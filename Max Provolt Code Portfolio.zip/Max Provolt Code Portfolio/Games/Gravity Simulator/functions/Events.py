import pygame
from classes.Constants import Constants
from classes.ClickActions import ClickActions
from classes.SpriteGroups import SpriteGroups

#Function controlling the key and mouse strokes on the screen globally. Does not control individual button presses.
def events():

    mouse = pygame.mouse.get_pos()
    mouseStrokes = pygame.mouse.get_pressed()
    keys = pygame.key.get_pressed()

    for button in SpriteGroups.buttons:
        if button.rect.collidepoint(mouse):
            return False #The return does not matter, what does is that the events method is ignored
            
    if mouseStrokes[0] and not Constants.isLeftClick:
        
        Constants.origin = mouse
        Constants.isLeftClick = True

    if not mouseStrokes[0] and Constants.isLeftClick:
        
        xVel = (Constants.origin[0] - mouse[0]) / Constants.POWER_SENSITIVITY
        yVel = (Constants.origin[1] - mouse[1]) / Constants.POWER_SENSITIVITY

        ClickActions.createBody(xVel, yVel)

        Constants.isLeftClick = False