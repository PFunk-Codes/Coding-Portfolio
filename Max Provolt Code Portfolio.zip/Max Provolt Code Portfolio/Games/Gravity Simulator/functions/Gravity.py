import math

from classes.Constants import Constants
from classes.SpriteGroups import SpriteGroups

# Function controlling the application of gravity between objects.
def gravity():

    for target in SpriteGroups.bodies:
        for satellite in SpriteGroups.bodies:
            if not (target == satellite):

                xDist = target.center[0] - satellite.center[0]
                yDist = target.center[1] - satellite.center[1]
                r = math.sqrt((xDist ** 2) + (yDist ** 2))

                try:
                    sinA = ((yDist ** 2) + (r ** 2) - (xDist ** 2)) / (2 * yDist * r)
                except:
                    sinA = 0

                try:
                    cosA = ((xDist ** 2) + (r ** 2) - (yDist ** 2)) / (2 * xDist * r)
                except:
                    cosA = 0
                
                #print('sin - ' + str(sinA) + ', cos - ' + str(cosA))

                acceleration = ((Constants.G * (target.m * satellite.m)) / r ** 2) / target.m

                target.xVel += acceleration * -cosA
                target.yVel += acceleration * -sinA

    for target in SpriteGroups.bodies:
        for sun in SpriteGroups.suns:

            xDist = target.center[0] - sun.center[0]
            yDist = target.center[1] - sun.center[1]
            r = math.sqrt((xDist ** 2) + (yDist ** 2))

            try:
                sinA = ((yDist ** 2) + (r ** 2) - (xDist ** 2)) / (2 * yDist * r)
            except:
                sinA = 0

            try:
                cosA = ((xDist ** 2) + (r ** 2) - (yDist ** 2)) / (2 * xDist * r)
            except:
                cosA = 0
            
            #print('sin - ' + str(sinA) + ', cos - ' + str(cosA))

            acceleration = ((Constants.G * (target.m * sun.m)) / r ** 2) / target.m

            target.xVel += acceleration * -cosA
            target.yVel += acceleration * -sinA