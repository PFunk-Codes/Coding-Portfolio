from classes.SpriteGroups import SpriteGroups

#function controlling the collision logic for certain bodies.
def collisions():

    for body1 in SpriteGroups.bodies:
        for body2 in SpriteGroups.bodies:
            if not (body1 == body2):
            
                if body1.rect.colliderect(body2.rect):

                    body1.kill()
                    body2.kill()