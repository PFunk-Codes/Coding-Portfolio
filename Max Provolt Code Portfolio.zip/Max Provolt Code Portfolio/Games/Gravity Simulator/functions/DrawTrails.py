from classes.Trail import Trail
from classes.SpriteGroups import SpriteGroups

#function controlling the drawing of trails behind a body.
def drawTrails():

    for body in SpriteGroups.bodies:

        trail = Trail(body.x + (body.w / 2), body.y + (body.h / 2), 'planet')
        SpriteGroups.allSprites.add(trail)