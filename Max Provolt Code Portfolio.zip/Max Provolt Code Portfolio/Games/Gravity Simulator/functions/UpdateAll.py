from classes.SpriteGroups import SpriteGroups

from functions.Gravity import gravity
from functions.Events import events
from functions.DrawTrails import drawTrails
from functions.Collisions import collisions

#The final called function to perform the full logic of the game. Called once per game loop cycle.
def updateAll():

    gravity()
    events()
    SpriteGroups.allSprites.update()
    drawTrails()
    collisions()