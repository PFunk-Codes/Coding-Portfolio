from classes.Constants import Constants
from classes.Body import Body
from classes.SpriteGroups import SpriteGroups

#A collection of static methods to be used when the screen is clicked.
class ClickActions:

    @staticmethod
    def createBody(xVel, yVel):

        body = Body(Constants.origin[0], Constants.origin[1], xVel, yVel, Constants.currentBodySize, Constants.currentBodySize, Constants.currentBodyMass, 'planet')
        SpriteGroups.allSprites.add(body)
        SpriteGroups.bodies.add(body)