import pygame

#A general purpose class, inherited by all other classes, that gives a variety of position related methods.
class Entity(pygame.sprite.Sprite):

    def updatePosition(self):

        self.x += self.xVel
        self.y += self.yVel

        self.center = [self.x - (self.w / 2), self.y + (self.h / 2)]

    def setPosition(self):

        self.rect.x = self.x
        self.rect.y = self.y

    def stopX(self):

        self.xVel = 0

    def stopY(self):

        self.yVel = 0

    def stop(self):

        self.stopX()
        self.stopY()

    def spriteRender(self):

        self.image = pygame.transform.scale((pygame.image.load(self.imageName)), (self.w, self.h))   