import pygame

#A place to store sprites. These could be stored in constants, but that doesn't make a whole lot of sense.
class SpriteGroups:
    
    allSprites = pygame.sprite.Group()
    buttons = pygame.sprite.Group()
    bodies = pygame.sprite.Group()
    suns = pygame.sprite.Group()
    