import pygame
from classes.Entity import Entity
from classes.Constants import Constants

#A class which represents a point of the trail of a body instance.
class Trail(Entity):

    def __init__(self, x, y, file):

        pygame.sprite.Sprite.__init__(self)

        self.w = Constants.TRAIL_THICKNESS
        self.h = Constants.TRAIL_THICKNESS

        self.x = x
        self.y = y

        self.color = (255, 255, 255)
        self.file = file

        self.image = pygame.Surface([self.w, self.h])
        self.imageName = Constants.IMG_DIR + self.file + '/render.png'

        self.rect = self.image.get_rect()
        self.rect.center = [self.x, self.y]

        self.time = Constants.TRAIL_LENGTH
                                    
    def countFrames(self):

        self.time -= 1

        if self.time <= 0:
            self.kill()

    def update(self):

        self.countFrames()
        self.spriteRender()