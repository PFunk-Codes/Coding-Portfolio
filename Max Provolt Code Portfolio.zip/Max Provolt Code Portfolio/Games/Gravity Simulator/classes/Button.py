import pygame
from classes.Entity import Entity

#A class that represents a button.
class Button(Entity):

    def __init__(self, x, y, w, h, action, buttonColor, textColor, fontSize, text):

        pygame.sprite.Sprite.__init__(self)

        self.w = w
        self.h = h

        self.action = action

        self.buttonColor = buttonColor
        self.textColor = textColor
        self.fontSize = fontSize

        self.image = pygame.Surface([self.w, self.h])

        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y

        self.font = pygame.font.Font('freesansbold.ttf', self.fontSize)
        self.text = self.font.render(text, True, self.textColor)
        self.textrect = self.text.get_rect(center = self.image.get_rect().center)
        self.image.fill(buttonColor)
        self.image.blit(self.text, self.textrect)

        self.isClicked = False

    def events(self):

        self.mouse = pygame.mouse.get_pos()
        self.buttons = pygame.mouse.get_pressed()
        self.keys = pygame.key.get_pressed()

        if self.getHover() and self.buttons[0] and not self.isClicked:
            
            self.action()
            self.isClicked = True
            
        if not self.getHover():
            self.isClicked = False
        if not self.buttons[0] and self.isClicked:
            self.isClicked = False

    def getHover(self):

        return self.rect.collidepoint(self.mouse)

    def update(self):

        self.events()