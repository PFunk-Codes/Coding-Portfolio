import pygame
from classes.Entity import Entity
from classes.Constants import Constants

#A gravitational object. 
class Body(Entity):

    def __init__(self, x, y, xVel, yVel, w, h, m, file):

        pygame.sprite.Sprite.__init__(self)

        self.w = w
        self.h = h

        self.x = x
        self.y = y
        self.center = [self.x - (self.w / 2), self.y + (self.h / 2)]

        self.color = (255, 255, 255)
        self.file = file

        self.image = pygame.Surface([self.w, self.h])
        self.imageName = Constants.IMG_DIR + self.file + '\\render.png'

        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y

        self.xVel = xVel
        self.yVel = yVel
        self.prevXVel = 0
        self.prevYVel = 0

        self.m = m

    def setPreviousPosition(self):

        self.prevX = self.rect.x
        self.prevY = self.rect.y

    def setPreviousVelocity(self):

        self.prevXVel = self.xVel
        self.prevYVel = self.yVel

    def update(self):

        self.updatePosition()
        self.setPosition()
        self.spriteRender()
