from classes.Constants import Constants
from classes.SpriteGroups import SpriteGroups

#A collection of static methods to be used by buttons when they are clicked.
class ButtonActions:

    @staticmethod
    def reset():

        for sprite in SpriteGroups.allSprites:
            if sprite not in SpriteGroups.buttons:

                sprite.kill()

    @staticmethod
    def setBody(bodySize, bodyMass):

        Constants.currentBodySize = bodySize
        Constants.currentBodyMass = bodyMass

    @staticmethod
    def setSmallBody():

        Constants.currentBodySize = Constants.smallBodySize
        Constants.currentBodyMass = Constants.smallBodyMass

    @staticmethod
    def setMediumBody():

        Constants.currentBodySize = Constants.mediumBodySize
        Constants.currentBodyMass = Constants.mediumBodyMass

    @staticmethod
    def setLargeBody():

        Constants.currentBodySize = Constants.largeBodySize
        Constants.currentBodyMass = Constants.largeBodyMass