import pygame, os

print(os.path.abspath(__file__))

#Constants and other variables to be used by all files, including main.
class Constants:

    origin = (0, 0)
    isLeftClick = False
    
    smallBodySize = 5
    smallBodyMass = 1
    mediumBodySize = 10
    mediumBodyMass = 5
    largeBodySize = 25
    largeBodyMass = 25
    currentBodySize = smallBodySize
    currentBodyMass = smallBodyMass
    
    DIR = os.path.abspath(__file__).replace('classes\Constants.py', '')
    IMG_DIR = DIR + 'images\\'
    BG_COLOR = (255, 255, 255)
    SCREEN_WIDTH = 750
    SCREEN_HEIGHT = 750
    SCREEN = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
    
    ZOOM = 1
    G = 10
    TRAIL_LENGTH = 20
    TRAIL_THICKNESS = 2
    POWER_SENSITIVITY = 100