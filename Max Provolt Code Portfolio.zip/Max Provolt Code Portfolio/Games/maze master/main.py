import pygame, os

class Entity(pygame.sprite.Sprite):

    def update_position(self):

        self.rect.x += self.xVel
        self.rect.y += self.yVel

    def stop_xVel(self):

        self.xVel = 0

    def stop_yVel(self):

        self.yVel = 0

    def stop_vel(self):

        self.stop_xVel()
        self.stop_yVel()

    def sprite_render(self):

        self.image = pygame.transform.scale((pygame.image.load(self.image_name)), (self.width, self.height))   

class Player(Entity):

    def __init__(self, xPos, yPos, width, height, file):

        pygame.sprite.Sprite.__init__(self)

        self.width = width
        self.height = height

        self.xPos = xPos
        self.yPos = yPos

        self.color = (255, 255, 255)
        self.file = file

        self.image = pygame.Surface([self.width, self.height])
        self.image_name = img_dir + self.file + "render.png"

        self.rect = self.image.get_rect()
        self.rect.x = self.xPos
        self.rect.y = self.yPos

        self.xVel = 0
        self.yVel = 0
        self.speed = (4 / 25) * zoom

    def prev_pos(self):

        self.prev_xPos = self.rect.x
        self.prev_yPos = self.rect.y

    def events(self):

        self.keys = pygame.key.get_pressed()
 
        self.movements()

    def movements(self):

        if self.keys[pygame.K_RIGHT]:
            self.rect.x += self.speed
        if self.keys[pygame.K_LEFT]:
            self.rect.x -= self.speed
        if self.keys[pygame.K_UP]:
            self.rect.y -= self.speed
        if self.keys[pygame.K_DOWN]:
            self.rect.y += self.speed

    def update(self):

        self.prev_pos()
        self.events()
        self.update_position()
        self.sprite_render()

class Wall(Entity):

    def __init__(self, xPos, yPos, width, height, file):

        pygame.sprite.Sprite.__init__(self)

        self.xPos = xPos
        self.yPos = yPos

        self.width = width
        self.height = height

        self.file = file
        self.color = (255, 255, 255)

        self.image = pygame.Surface([self.width, self.height])
        self.image_name = img_dir + self.file + "render.png"

        self.rect = self.image.get_rect()
        self.rect.x = self.xPos
        self.rect.y = self.yPos

    def update(self):

        self.sprite_render()

class Goal(Wall):

    pass

class Text(Entity):

    def __init__(self, xPos, yPos, width, height):

        pygame.sprite.Sprite.__init__(self)

        self.xPos = xPos
        self.yPos = yPos

        self.width = width
        self.height = height

def generate_level(scale):

    try:
        raw_level = open((lvl_dir + "L" + str(current_lvl) + ".txt"), "r")
    except FileNotFoundError:
        raw_level = open((lvl_dir + "finish.txt"), "r")

    level = raw_level.readlines()
    raw_level.close()
        
    x = y = 0
    
    for row in level:
        for tile in row:
            if tile == "W":
                wall = Wall(x, y, scale, scale, "wall/")
                walls.add(wall)
                allSprites.add(wall)
            elif tile == "P":
                player = Player(x, y, int(.75 * scale), int(.75 * scale), "player/")
                players.add(player)
                allSprites.add(player)
            elif tile == "G":
                goal = Goal(x, y, scale, scale, "goal/")
                goals.add(goal)
                allSprites.add(goal)
            x += scale
        x = 0
        y += scale

def optimize():

    pass

    # An inherent problem with using a text file to create individual grid
    # patterns is that the amount of sprites that are generated is vastly
    # inefficient. The number of entities processed can be lowered greatly
    # by combining walls together to form a single sprite, which retains the
    # same shape and functionality for the game. This function should be
    # written to combine adjacent sprites together to reduce the number of
    # sprites on the screen.

def screen_roll():

    for player in players:
        xshift = screen_width / 2 - player.rect.center[0]
        yshift = screen_height / 2 - player.rect.center[1]
        for sprite in allSprites:
            sprite.rect.x += xshift
            sprite.rect.y += yshift

def collisions():

    for player in players:
        for wall in walls:

            if pygame.sprite.collide_rect(player, wall):

                if player.prev_xPos + player.width <= wall.rect.left:

                  player.rect.x = wall.rect.x - player.width
                  player.stop_xVel()

                if player.prev_xPos >= wall.rect.right:

                  player.rect.x = wall.rect.x + wall.width
                  player.stop_xVel()

                if player.prev_yPos + player.height <= wall.rect.top:

                  player.rect.y = wall.rect.y - player.height
                  player.stop_xVel()

                if player.prev_yPos >= wall.rect.bottom:

                  player.rect.y = wall.rect.y + wall.height
                  player.stop_xVel()

    for player in players:
        for goal in goals:

            if pygame.sprite.collide_rect(player, goal):

                for sprite in allSprites:

                    sprite.kill()

                global current_lvl
                current_lvl += 1

                generate_level(zoom)
                optimize()
    

def update_all():

    allSprites.update()
    collisions()
    screen_roll()


screen_width = 1280
screen_height = 720
screen = pygame.display.set_mode((screen_width, screen_height))
bg_color = (255, 255, 255)
directory = os.path.dirname(os.path.realpath("level mapping.py")) + "/"
img_dir = directory + "images/"
lvl_dir = directory + "levels/"
end_shell = False
total_frames = 0
current_lvl = 1
counter = 0
zoom = 50

pygame.init()

pygame.display.set_caption("Level Mapping Experimentation")

fps = 60
clock = pygame.time.Clock()

allSprites = pygame.sprite.Group()
walls = pygame.sprite.Group()
players = pygame.sprite.Group()
goals = pygame.sprite.Group()

generate_level(zoom)
optimize()

for sprite in allSprites:
    counter += 1
print(str(counter))

while not end_shell:

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            end_shell = True

    screen.fill(bg_color)

    update_all()

    allSprites.draw(screen)

    total_frames += 1

    pygame.display.update()
    clock.tick(fps)

pygame.quit()
