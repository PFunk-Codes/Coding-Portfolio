The purpose of this project is to separate the collision of a player from its appearance.

Say you had a character. This character is a perfect circle. Along comes a bullet, coming diagonally at the side of the circle. If there was no separation, the bullet could hit the circle if it hit the corner of the rect that the circle was on. If you could separate the circle into the visual circle and a rectangle which handles being hit by the bullets, you could make the rectangle smaller and better reflect the shape of the circle.

Obviously, a circle is a pretty bad example. Actually, it's the worst example. However, for something like a character in the game, which has a humanoid figure, this solution is vastly more applicable. A player's arms and legs extend out relatively far, away from the torso. This means that anywhere within this large rectangle, even where there isn't any visual contact, will be registered as a hit. So, you can create a rectangle which is fixed in size that would reflect the area where a bullet would hit the player, and then a rectangle that can vary in size that has dynamically changing visuals that reflect how a player would move.

This is why I embarked on this project. I have two ideas for it; one is using two separate objects with a uuid system, and the other is using multiple surfaces in one object. Today, I designed the uuid system. However, the other one may be better, or a combination of both.

Essentially, uuid stands for Universal Unique Identifier. There are two separate objects in memory, the CollisionBox and the Texture. When the CollisionBox is created, it is created with a number which is its uuid. It then creates a Texture with the same uuid, and an image directory. The CollisionBox will tell the Texture what image to render, and the Texture will fix itself to the CollisionBox as the CollisionBox moves.

The last unimplemented feature of this system is an algorithm that ensures that the uuid of a CollisionBox Texture pair is actually unique. This could be done fairly simply in theory, but any unforeseen kinks are yet to be explored, or even considered.

The second design, as foreshadowing, will attempt to use multiple surfaces in one class object. I have yet to even see if this is possible, but if it is, it will make data transmission and class instantiation far easier. It is clearly the preferred design, but this one works in the case of failure.

I have included two versions of the code; one that is totally unmodified, and the other with fairly adequate notes explaining the code and its functionality. I did this so that you, the reader, could understand the code without having to deal with comments as you edit the file. I find this incredibly annoying, especially when you don't delete the comments and they aren't even useful anymore.

Thank you for taking the time to look at my work. If you feel so compelled, work on this and expand it.

-Max