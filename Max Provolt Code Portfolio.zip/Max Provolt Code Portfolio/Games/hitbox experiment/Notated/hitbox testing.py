########################################
# Original Author | Maximilian Provolt #
########################################

import pygame, time, os



class Entity(pygame.sprite.Sprite): #Defining a base class with extremely basic manipulation functions. Almost everything in a game needs these somewhere.

    def updatePosition(self):

        self.rect.x += self.vel[0]
        self.rect.y += self.vel[1]

    def storePosition(self): #This function is used for storing the position. This is called before the position is changed with update_position().
                             #It is used for collision detection and distance calculations.

        self.prev_x = self.rect.x
        self.prev_y = self.rect.y

    def stopXVel(self):

        self.vel[0] = 0

    def stopYVel(self):

        self.vel[1] = 0

    def stopVel(self):

        self.stopXVel()
        self.stopYVel()

    def imgRender(self): #pygame.transform.scale(Surface, (x, y)) --> Surface. Essentially, this function scales an image to the dimensions stipulated, then creates a pygame
                         #surface for it. here, all of the arguments are defined later in the instantiated class rather than here.

        self.image = pygame.transform.scale((pygame.image.load(self.img_name)), (self.w, self.h))



class CollisionBox(Entity):

    def __init__(self, hx, hy, hw, hh, tx, ty, tw, th, tfile, uuid): #There are two sets of (x, y, w, h) here for a reason. The CollisionBox, when instantiated, creates a
                                                                     #Texture with the same uuid as given. However, the texture may not necessarily be the same size as the
                                                                     #CollisionBox, so there are two sets of coordinates and dimensions to allow the Texture its own values.
                                                                     #The uuid stands for universal unique identifier. It allows the Texture to know which CollisionBox to
                                                                     #adhere to, and the CollisionBox which texture to send data to. Sending data has not been implemented yet,
                                                                     #but oh boy, it will.

        pygame.sprite.Sprite.__init__(self)

        self.w = hw
        self.h = hh

        self.image = pygame.Surface([self.w, self.h]) #This surface is just temporary, since there must be a surface in order to derive a rect object.
        
        self.img_name = img_dir + "hitbox/" + "render.png" #This string is the directory of a 1x1 px clear image file. This way, the CollisionBox will be rendered as a clear
                                                           #box, so as to not interfere with the Texture. However, for the sake of visualizing the CollisionBox versus the
                                                           #Texture, I have removed the imgRender() from the Player class, so that you can see the Surface as a black box.

        self.rect = self.image.get_rect()
        self.rect.x = hx
        self.rect.y = hy

        self.vel = [0, 0] #I found it easier to treat the velocity as a list of the separate directional velocities. If you disagree with this, too bad.
        self.speed = 5 #A measure of movement velocity in pix/frame. This is used during motion calculations.

        self.uuid = uuid

        texture = Texture(tx, ty, tw, th, tfile, self.uuid) #Getting the arguments from the CollisionBox's arguments.
        textures.add(texture) #Creating the Texture and adding it to the textures group. Doing it here makes it extremely easy to attach the same uuid as its CollisionBox.



class Texture(Entity):

    def __init__(self, x, y, w, h, file, uuid):

        pygame.sprite.Sprite.__init__(self)

        self.w = w
        self.h = h

        self.file = file
        self.image = pygame.Surface([self.w, self.h])
        self.img_name = img_dir + self.file + "render.png" #Employing the use of self.file allows for the use of different folders to find the image desired. img_dir is the
                                                           #directory up to the /images folder. After this, self.file is the directory of the image up to the actual image,
                                                           #which will always be named render.png. This way, all you have to do in order to change the image that renders is
                                                           #change the argument to a new directory when instantiating a new object.

        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y

        self.vel = [0, 0]

        self.uuid = uuid #The uuid for the Texture. Note that the way CollisionBox is written, it necessitates that this uuid is matched by at least 1 CollisionBox's uuid.

    def update(self): #Update is the function that is actually called by the main loop. Any function that is included in here will attempt to run every  cycle. Note that
                      #functions written in the class but not included here will be included in the class object, but will not be run every cycle in this function.

        self.updatePosition()
        self.imgRender()



class Player(CollisionBox): #Inheriting CollisionBox's attributes. Note that the Texture class does not check what type of object when checking for uuid, so this Player class
                            #can interact with Textures identically as a CollisionBox. Additionally, the Player class can add more functionality without impacting the
                            #framework of the CollisionBox class.

    def events(self):       #All events processed by the Player object are handled in this function. This function is called first in update(), as then all other functions
                            #which use that data can do so. In the case of expansion of a game, mouse and touchscreen input may also be added to this.

        self.keys = pygame.key.get_pressed()

    def movements(self): #Basic movement function. Not much to explain.

        self.vel[0] = 0
        self.vel[1] = 0

        if self.keys[pygame.K_RIGHT]:
            self.vel[0] = self.speed
        if self.keys[pygame.K_LEFT]:
            self.vel[0] = -self.speed
        if self.keys[pygame.K_UP]:
            self.vel[1] = -self.speed
        if self.keys[pygame.K_DOWN]:
            self.vel[1] = self.speed

    def update(self):

        self.events()
        self.movements()
        self.storePosition()
        self.updatePosition()
        #self.imgRender()



class Wall(CollisionBox): #This basically just differentiates a CollisionBox from a Wall, which may have added features in the future. However, right now, they are the same.

    pass


        
def collisionHandling(): #This is the collision detection for the game. It will select two groups of sprites, and outline the actions taken upon a member of the two colliding.

    for player in players:
        for wall in walls:

            if pygame.sprite.collide_rect(player, wall):

                if player.prev_x + player.w <= wall.rect.left:

                    player.rect.x = wall.rect.x - player.w
                    player.stopXVel()

                if player.prev_x >= wall.rect.right:

                    player.rect.x = wall.rect.x + wall.w
                    player.stopXVel()

                if player.prev_y + player.h <= wall.rect.top:

                    player.rect.y = wall.rect.y - player.h
                    player.stopYVel()

                if player.prev_y >= wall.rect.bottom:

                    player.rect.y = wall.rect.y + wall.h
                    player.stopYVel()

def assignTextures(): #This is where the essence of this entire project lies. This function will go through a group of sprites and the textures group in a nested for loop.
                      #It will then go through the textures until it finds the one whose uuid matches the unique sprite. It then moves the center of the texture to the center
                      #of the sprite. The purpose of this is to allow two rectangles to be in use; the visual rectange, and the collision rectangle. This differentiation can
                      #allow for a collision area which better reflects how a character should behave in its environment.

    for hitbox in collision_boxes:
        for texture in textures:

            if hitbox.uuid == texture.uuid:

                texture.rect.center = hitbox.rect.center

                break
            
    for player in players:
        for texture in textures:

            if player.uuid == texture.uuid:

                texture.rect.center = player.rect.center

                break
    

def updateAll(): #This combines all of the calculations required for the game to work into one callable function. This is simply for ease of use.

    all_sprites.update()
    collisionHandling()
    assignTextures()



screen_width = 500
screen_height = 500
screen = pygame.display.set_mode((screen_width, screen_height))
bg_color = (255, 255, 255)
directory = os.path.dirname(os.path.realpath("hitbox testing.py")) + "/" #This returns the parent directory of the .py file. Assuming you opened this in your desktop, that
                                                                         #would be {/Users/(username)/Desktop/hitbox experiment/Notated/} on Mac OS.
img_dir = directory + "images/"
end_shell = False
total_frames = 0
zoom = 50 #This may be used for tuning the scale of the sprites on the screen. When rendered, this will act as a multiplier for the sprite's size.

pygame.init() #Initializing the pygame libraries.

pygame.display.set_caption("Hitbox Testing") #Setting the name of the pygame window.

fps = 60
clock = pygame.time.Clock() #creating a time stepper which will periodically load a new frame when the .tick(fps) function is called.

all_sprites = pygame.sprite.Group() #creating the necessary groups.
textures = pygame.sprite.Group()
collision_boxes = pygame.sprite.Group()

players = pygame.sprite.Group()
walls = pygame.sprite.Group()

player = Player(0, 0, 50, 50, 0, 0, 100, 100, "player/", 0) #creating the instances of the classes required.
wall = Wall(250, 250, 100, 100, 250, 250, 100, 100, "wall/", 1)

#textures.add(())
players.add((player)) #adding the instances to their respective groups.
walls.add((wall))
all_sprites.add((players, walls, textures))



while not end_shell: #This is the main loop. All of the code above this was just setup for this to actually run.

    for event in pygame.event.get(): #This piece will force exit the main loop when the close window button is clicked.
        if event.type == pygame.QUIT:
            end_shell = True

    screen.fill(bg_color) #Wipes the screen. The screen is a surface in pygame, and is not necessarily what shows on the physical monitor. The screen is only shown when
                          #pygame.display.update() is called. Therefore, we can make changes without them being noticed by the human player in real time.
    
    updateAll() #Performs all game calculations.

    all_sprites.draw(screen) #Draws all of the new sprites and their states to the screen surface.

    total_frames += 1 #This can be treated like a timer, independent of the real cpu time and counting in-game time. It is not used currently, but doesn't take much space.

    pygame.display.update() #Updates the display, showing the new changes all at once.
    clock.tick(fps) #Tells pygame to wait for a specific amount of time, which is 1/fps seconds.

pygame.quit() #Once the mainloop has completed, deinitialize the pygame libraries. This will close the window in an error free manner.
