This Repository is filled with my personal projects that are at varying degrees of completion in the past 4 years. They highlight my progression as an independent developer throughout my high school career.

All of these I give at least partial credit to my coding mentor, high school teacher, and fellow enthusiast, Adam Wolfe. His insight into the methodology and vocabulary of python and other compiled languages like C has been instrumental to my endeavors. He is also a fantastic teacher, coach, personality, inspiration, and friend.

I'm going to go through each of these projects in order, and describe them in as much detail as I can. Some of them I can't remember too well, as I wrote them many years ago as a novice.

Please, if anyone you know has the urge to edit these files and make something more out of them, by all means, send them this. I have a copy on my hard drive, it'll be fine. I'd love to see where they take my ideas.



> Games

	> hitbox experiment

This project is a proof of concept for separating the logical part of the game character with the visual part in pygame. Pygame sprites are Surface type objects in memory, where collisions and image rendering are both handled. So, I created two sprites with different surfaces and used a UUID to bind their positions together in a parent function. I think it worked pretty well, considering I had no outside assistance in the logic. I describe it a little bit better in the README in that folder, and there is also a version of the .py file with notes and without, for ease of editing.

	> maze master

This one was fun. I made this also as a proof of concept for an idea I had; to create customizable level generation. Since the idea relies on a grid pattern to work, I figured mazes were a good genre to explore. The game has a player you control, maze walls that you can't go through, and a yellow goal. When the player touches the goal, the game generates the new level and you play that. What's great is that you can edit the file with levels and create your own. There's a README in there, too, but basically, I used nested for loops to go character by character and create a sprite at a specified location. Reading the code for it is probably easier... All the code for the level generation is in generate_level(scale). That's the main selling point, though; otherwise, you just solve mazes until the levels run out. Was extremely satisfying to iron the kinks out in the logic and create a functional level editor system.

One day quite a while after I accomplished my original task, I revisited the game with the intention of designing two things; a menu system with GUI, and a settings menu. I decided to change the entire way I went about organizing my code, by splitting the classes and functions into separate files instead of keeping them in one (my games were not complex enough to need splitting classes into files before). Although I had never done something like this before, and I did a pretty shoddy job of it, I did achieve what I set out to do. A menu does exist within the game, and you can use the settings menu to change the color of the walls. Extremely rudimentary, but this yet again is a core developmental accomplishment for me.

	> megamax

This one goes back the farthest. I made this at least 4 years ago, probably more. This is also the project that I spent the most amount of time on for a while. I was planning on making a full game, with title screen, menus, a story, fight mechanics, the works. I soon found out I lacked the dedication at 14 to do something so large by myself. Anyways, in this game, I for the first time programmed an image management system, gravity, projectile firing, multiple players, sprite animation, collision detection, and even sound playback (although now it is defunct). I am proud of the idea that this represents, and I am also fond of all of the memories of technical challenges that I overcame creating this. However, I have moved on to other projects now, and looking back, it is quite rudimentary. We all have to start somewhere, though.

	> minesweeper

Exactly what it sounds like. I made minesweeper in 4 hours one night when I was bored at my dad's house. I was surprised to see it work my first try, albeit extremely buggily. Usually, I make a syntax error somewhere that doesn't even let anything appear in the pygame window, but it somehow functioned generally as intended first try. I fixed some of the bugs, but there are still times where the game will freeze for no reason. If this happens, just close the shell. I intend to attempt to remake the game to be less buggy, and also potentially add some semblance of menu functionality. But for now, have my very glitchy and unstable version of minesweeper.

	> Gravity Simulator
	
This was the most satisfying project I've completed. Once I got more interested in astrophysics as a hobby, I decided to design my own gravity simulator, similar to flash games that you might see online. I had experience creating objects and manipulating their motion with acceleration, so I knew that all I had to do was simulate the gravitational equation and set the forces and velocities with the distances to the other objects. I knew what to do... But the math ate up probably a week of my off-time. I was slamming my head into the wall to figure out how the math actually applied to the objects I was using. Eventually, I figured out the trigonometry using pythagoras' theorem, and finally got the objects to gravitationally attract. I remember where I was when I got it to work; in AP Computer Science, after I had completed the homework for that day, and I was toying with the code before class ended. The biggest grin came over my face when I got it to work, and I showed all of my friends in the class and my teacher before I left. Later, I went back and added buttons to switch the size of the objects in the interface (before, you had to switch object types with shell prompts).

If you want to play with the sim, use the buttons to change the size and mass of the objects. In order to place objects, click on the canvas. To impart an initial velocity on the object, click and drag to shoot it like a slingshot, the further you drag the higher the velocity. There are also constants in the classes folder, if you wish to change the strength of gravity, the masses and sizes of the object types, and other parameters.

> Math Stuff

	> Factors
	
		> Factors Calculator

Simple peice of code that will calculate the factors of a given number. Also, I got fancy with tkinter, so the entire UI is in a window. Can be optimized, but I don't see the need to do it unless I make a website or something.

		> GCF Calculator

First finds the factors of two input numbers, then compares the two lists and finds the greatest in value. Fairly simple as well, but actually more useful than you think in math class.

		> pi estimator

This needs a little bit of mathematical explaining. There is a youtube channel called standupmaths run by a guy called Matt Parker, and every March 14th he makes a pi day video where he calculates pi in weird ways. Last year's was using random number coprime probabilities. If you generate pairs of random numbers, see if they are coprime or not, then divide the total coprime pairs by the total pairs, you get a number.
the square root of (6 divided by that number) is approximately pi. Don't ask me why or how, but it is. And the way Matt Parker showed this was by rolling a ton of dice and writing down the tally of coprime pairs by hand. Obviously, for entertainment's sake. He could have written a js script to do it for him in a tenth of a second. That's what I did here. I combined the other two projects in this folder with the math in the video
and made this. It actually works surprisingly well; sometimes, you can get up to 4 decimals or more of precision. Just be careful about putting in too large of a number, because it can get to be a long wait.
I also added in a progress notifier, where it will print out every 20000 pairs to let you know where it is. It's quite nice, and an interesting exercise demonstrating the fact that circles are everywhere in math, no matter how hidden they may be.

	> Julia Sets
		
This entire folder is my favorite thing I've done in python. If you know much about complex numbers, or been on youtube in 2014, you've probably heard of the mandelbrot set. Essentially, it is an iteration of a function with complex numbers (a + bi), and whether or not the result of the iteration explodes to infinity or stays finite is what determines whether or not the respective number is in the set. It is hard to explain, but it is much more interesting to look at. It happens to be a fractal, a geometric shape with infinite complexity and recursive behavior. If you zoom in far enough into the set, you will see the set reappear. And you can zoom into the same point on the miniature set, and find it again.

		> Mandelbrot tester single
		
The first successful attempt at programming the fractal generation algorithm. It uses text to create the set, and has no gradient, like other fractal generators, only black and white inclusion and exclusion. It was important for me to fully understand the algorithm before I designed more features.

		> Mandelbrot gradient
		
This version did include a gradient for the outliers of the set. This is more in line with the online generators you will see, and does an okay job at illustrating the more complex structures hidden within the black regions of the set.

		> fractal generator
		
This version is a big step up. Instead of using ASCII text to represent the set, this version uses turtle, a GUI library of python. I address each individual pixel of the screen in turtle to generate the fractal. You can control the resolution of the calculation (how many passes of the iteration before the complex number is included in the set), and the resolution of the image (px x px). I remember seeing the image appear for the first time, and just shivering from the fact that I had made that image myself, when I had seen it so many times on the internet. It was a really cool feeling, and it motivated me to continue working on the project.

		> Fractal Generator Interactive
		
This is the current version of the project that I've left it on. The main addition is the ability to zoom in on the image after it has concluded generating. You can zoom as many times as you like, and it will continue to delve deeper and deeper into the hidden structures within the set. You can also find mini mandelbrots, self-recursive resurrections of the set within the set, sometimes mangled and stretched because of their location within the whole set. It is really interesting to explore this minefield, and contemplate that you might be exploring shapes where human eyes have never seen before.

I've also included other fractals that you can change between. You have to change them within the code, as I have not programmed a menu for this project yet, but the other fractals do indeed generate, with the same zooming capability.



Thank you for reading through this. It humbles me that I can share my coding journey through the years with others, as these projects have a large emotional attachment to me. They represent the tasks I have overcome, the lessons I have learned, and my own curiosity and passion for code.