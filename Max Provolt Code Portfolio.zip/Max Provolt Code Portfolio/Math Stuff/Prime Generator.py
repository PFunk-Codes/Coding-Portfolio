def factors(value):

    out = ""
    if value < 2: #This statement merely checks if the number is less than or equal to two. It's pointless to run the code on numbers like this, so I exclude them immediately.
        print("Please insert a number greater than 2.")
    else:
        for x in range(int(value / 2)): #Loops for half the amount of value. Calculating for the numbers over half is pointless, since those numbers will never give whole number quotients.
            if value % (x + 1) == 0: #Tests if the remainder of value and x+1 is 0. If it is true, then x is a factor of value, since it evenly divides with value. +1 is necessary since x starts at 0, which returns an error upon first iteration.
                out = out + str(x + 1) + ", " #Adds x in for: loop to out. Notice the ", " string at the end; if this was not added, then out would result in all the numbers squished together unintelligibly. You must add spaces in out to make the numbers clear.
        return out + str(int(value)) #Finally, returns the factors of value.



while True:

    primes = []

    for x in range(int(input("Number to calculate primes up to:"))):

        value = factors(x + 2)
        if value == ("1, " + str(x + 2)):
            primes.append(str(x + 2))
        if x % 10000 == 0:
            print(str(x))

    print(primes)

    
    
