import tkinter

root=tkinter.Tk()

def clickButton():
  
  out=""
  userIn=entry.get() #the number the user wishes to find the factors of
  if userIn.isnumeric(): #Tests if userIn is a numeric string. If it is zero, then userIn is a number, since the previous try: statement succeeded. If intTest is 1, then the except: statement ran, and userIn is not a number. This is to prevent EOF errors from occurring when the computer tries to divide strings.
    userIn=int(userIn)
    if userIn<=2: #This statement merely checks if the number is less than or equal to two. It's pointless to run the code on numbers like this, so I exclude them immediately.
      label['text']="Please insert a number greater than 2."
    else:
      for x in range(int(userIn/2)): #Loops for half the amount of userIn. Calculating for the numbers over half is pointless, since those numbers will never give whole number quotients.
        if userIn%(x+1)==0: #Tests if the remainder of userIn and x is 0. If it is true, then x is a factor of userIn, since it evenly divides with userIn. +1 is necessary since x starts at 0, which returns an error upon first iteration.
          out=out+str(x+1)+", " #Adds x in for: loop to out. Notice the ", " string at the end; if this was not added, then out would result in all the numbers squished together unintelligibly. You must add spaces in out to make the numbers clear.
      if out=="1, ": #Tests to see if the only factor added to out was 1, since if the number is prime, this is the only number that would make up out.
        label['text']="PRIME"
      else: 
        label['text']="FACTORS : "+out+str(int(userIn)) #Finally, returns the factors of userIn.
  else:
    label['text']="Please insert a number."

button=tkinter.Button(root)
button['text']="FIND FACTORS"
button['command']=clickButton
button.grid(row=0,column=0)

entry=tkinter.Entry(root)
entry.grid(row=1,column=0)

label=tkinter.Label(root)
label['text']=""
label.grid(row=2,column=0)

root.mainloop()

