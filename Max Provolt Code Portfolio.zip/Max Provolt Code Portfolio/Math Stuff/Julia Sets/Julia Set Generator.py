import math
import cmath

cycle_str = "-"
img_res = 100
calc_res = 100

a = -2
b = 2
c = None

def testJulia(z, c, res):
    
    thresh = res

    for x in range(res):

        try:

            z = z**2 + c

        except ValueError:

            print("not a number")
            break

        except:

            print("error")
            break

        if math.sqrt(((z.real)**2)+(z.imag)**2) >= 2:

            thresh = x + 1
            break

    return thresh


while True:

    c = complex(input("Julia Set for complex number c: "))

    for y in range(img_res):
        for x in range(img_res):

            result = 0

            if math.sqrt((a**2)+(b**2)) <= 2:

                result = testJulia(complex(a, b), c, calc_res)

            if result == calc_res:
                cycle_str == "█"
            else:
                cycle_str == " "

            a += (1 / img_res * 4)

        b -= (1 / img_res * 4)
        a = -2
        print(cycle_str)
        cycle_str = "|"
                

    
    

    
