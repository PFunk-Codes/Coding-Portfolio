import math, cmath, timeit
from turtle import *

def testMandelbrot(c, res):

    z = 0
    thresh = res

    for x in range(res):

        try:

            z = z ** 2 + c

        except ValueError:

            print("not a number")
            break

        except:

            print("error")
            break
        
        if math.sqrt(((z.real) ** 2) + (z.imag) ** 2) >= 2:

            thresh = x + 1
            break

    return thresh

def testBurningShip(c, res):

    z = complex()
    thresh = res

    for x in range(res):

        try:

            z = complex((z.real ** 2) - (z.imag ** 2) - c.real, 2 * abs(z.real * z.imag) - c.imag)

        except Exception as e:

            print(e)
            break
        
        if math.sqrt(((z.real) ** 2) + (z.imag) ** 2) >= 2:

            thresh = x + 1
            break

    return thresh

def testTricorn(c, res):

    z = complex()
    thresh = res

    for x in range(res):

        try:

            z = complex(z.real, -z.imag) ** 2 + c

        except Exception as e:

            print(e)
            break
        
        if math.sqrt(((z.real) ** 2) + (z.imag) ** 2) >= 2:

            thresh = x + 1
            break

    return thresh

def testFeather(c, res):

    z = complex()
    thresh = res

    for x in range(res):

        try:

            z = ((z ** 3) / (1 + complex(z.real ** 2, z.imag ** 2) ** 2)) + c

        except Exception as e:

            print(e)
            break
        
        if math.sqrt(((z.real) ** 2) + (z.imag) ** 2) >= 2:

            thresh = x + 1
            break

    return thresh

def clickEvent(x, y):

    global zoom
    global cpoint
    global img

    zoom *= 3

    cpoint = draw(t, fractal, cpoint[0] + (x / (50 * (img / 200)) / zoom * 2), cpoint[1] + (y / (50 * (img / 200)) / zoom * 2), zoom, img, zoom * precision if zoom * precision < max_depth else max_depth)

    print(f'{zoom * 30}')



def draw(t, fractal, cx, cy, zoom, res, calc_res):

    start = timeit.default_timer()

    t.clear()

    tracer(1000, 0)

    seta = (cx - (2 / zoom))
    a = seta
    b = (cy + (2 / zoom))

    t.up()
    t.setpos(-(img / 2), (img / 2))
    t.down()

    print(seta)

    for y in range(res):
        for x in range(res):

            result = 1

            if math.sqrt((a**2)+(b**2)) <= 2:

                result = fractal(complex(a, b), calc_res)

            if result == calc_res:
                t.color('black')
            else:
                ratio = math.sqrt(calc_res / result)
                t.color((int(255 / ratio), int(255 / ratio), int(255 / ratio)))

            t.forward(1)

            a += ((1 / res * 4) / zoom)

        t.up()
        t.setpos(-(res / 2), t.ycor() - 1)
        t.down()
        
        b -= ((1 / res * 4) / zoom)
        a = seta

        #print(f'{int((res - (t.ycor() + (res / 2))) / (res / 100))}% complete')

    end = timeit.default_timer()
    print(f'{end - start} seconds')

    tracer(1, 0)

    return [cx, cy]

    



img = 200
max_depth = 500
precision = 100
center = [0, 0]
zoom = 1
fractal = testMandelbrot

zoom_counter = 0
point1 = []
point2 = []

screen = Screen()
screen.colormode(255)

t = Turtle()
t.speed(0)
t.hideturtle()
t.up()
t.setpos(-(img / 2), (img / 2))
t.down()



cpoint = draw(t, fractal, center[0], center[1], zoom, img, zoom * precision)

listen()

onscreenclick(clickEvent)

mainloop()
