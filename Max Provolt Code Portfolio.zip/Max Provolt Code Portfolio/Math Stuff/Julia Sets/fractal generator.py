import math, cmath, timeit
from turtle import *

img_res = 500
calc_res = 50

a = -2
b = 2

screen = Screen()
screen.colormode(255)

t = Turtle()
t.speed(0)
tracer(100, 0)
t.hideturtle()
t.up()
t.setpos(-(img_res / 2), (img_res / 2))
t.down()

def testMandelbrot(c, res):

    z = 0
    thresh = res

    for x in range(res):

        try:

            z = z ** 2 + c

        except ValueError:

            print("not a number")
            break

        except:

            print("error")
            break
        
        if math.sqrt(((z.real) ** 2) + (z.imag) ** 2) >= 2:

            thresh = x + 1
            break

    return thresh

def testBurningShip(c, res):

    z = complex()
    thresh = res

    for x in range(res):

        try:

            z = complex((z.real ** 2) - (z.imag ** 2) - c.real, 2 * abs(z.real * z.imag) - c.imag)

        except Exception as e:

            print(e)
            break
        
        if math.sqrt(((z.real) ** 2) + (z.imag) ** 2) >= 2:

            thresh = x + 1
            break

    return thresh

def testTricorn(c, res):

    z = complex()
    thresh = res

    for x in range(res):

        try:

            z = complex(z.real, -z.imag) ** 2 + c

        except Exception as e:

            print(e)
            break
        
        if math.sqrt(((z.real) ** 2) + (z.imag) ** 2) >= 2:

            thresh = x + 1
            break

    return thresh

def testFeather(c, res):

    z = complex()
    thresh = res

    for x in range(res):

        try:

            z = ((z ** 3) / (1 + complex(z.real ** 2, z.imag ** 2) ** 2)) + c

        except Exception as e:

            print(e)
            break
        
        if math.sqrt(((z.real) ** 2) + (z.imag) ** 2) >= 2:

            thresh = x + 1
            break

    return thresh



start = timeit.default_timer()

for y in range(img_res):
    for x in range(img_res):

        result = 1

        if math.sqrt((a**2)+(b**2)) <= 2:

            result = testMandelbrot(complex(a, b), calc_res)

        if result == calc_res:
            t.color('white')
        else:
            ratio = math.sqrt(calc_res / result)
            t.color((int(255 / ratio), int(255 / ratio), int(255 / ratio)))

        t.forward(1)

        a += (1 / img_res * 4)

    t.up()
    t.setpos(-(img_res / 2), t.ycor() - 1)
    t.down()
    
    b -= (1 / img_res * 4)
    a = -2

    print(str(int((img_res - (t.ycor() + (img_res / 2))) / (img_res / 100))) + '% complete')

end = timeit.default_timer()

print(str(end - start) + ' seconds')

