########################################
# Original Author | Maximilian Provolt #
########################################

import pygame, time, os



class Entity(pygame.sprite.Sprite):

    def updatePosition(self):

        self.rect.x += self.vel[0]
        self.rect.y += self.vel[1]

    def storePosition(self):

        self.prev_x = self.rect.x
        self.prev_y = self.rect.y

    def stopXVel(self):

        self.vel[0] = 0

    def stopYVel(self):

        self.vel[1] = 0

    def stopVel(self):

        self.stopXVel()
        self.stopYVel()

    def imgRender(self):

        self.image = pygame.transform.scale((pygame.image.load(self.img_name)), (self.w, self.h))



class CollisionBox(Entity):

    def __init__(self, hx, hy, hw, hh, tx, ty, tw, th, tfile, uuid):

        pygame.sprite.Sprite.__init__(self)

        self.w = hw
        self.h = hh

        self.image = pygame.Surface([self.w, self.h])
        self.img_name = img_dir + "hitbox/" + "render.png"

        self.rect = self.image.get_rect()
        self.rect.x = hx
        self.rect.y = hy

        self.vel = [0, 0]
        self.speed = 5

        self.uuid = uuid

        texture = Texture(tx, ty, tw, th, tfile, self.uuid)
        textures.add(texture)



class Texture(Entity):

    def __init__(self, x, y, w, h, file, uuid):

        pygame.sprite.Sprite.__init__(self)

        self.w = w
        self.h = h

        self.file = file
        self.image = pygame.Surface([self.w, self.h])
        self.img_name = img_dir + self.file + "render.png"

        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y

        self.vel = [0, 0]
        self.speed = 5

        self.uuid = uuid

    def update(self):

        self.updatePosition()
        self.imgRender()



class Player(CollisionBox):

    def events(self):

        self.keys = pygame.key.get_pressed()

        self.movements()

    def movements(self):

        self.vel[0] = 0
        self.vel[1] = 0

        if self.keys[pygame.K_RIGHT]:
            self.vel[0] = self.speed
        if self.keys[pygame.K_LEFT]:
            self.vel[0] = -self.speed
        if self.keys[pygame.K_UP]:
            self.vel[1] = -self.speed
        if self.keys[pygame.K_DOWN]:
            self.vel[1] = self.speed

    def update(self):

        self.events()
        self.storePosition()
        self.updatePosition()
        self.imgRender()



class Wall(CollisionBox):

    pass


        
def collisionHandling():

    for player in players:
        for wall in walls:

            if pygame.sprite.collide_rect(player, wall):

                if player.prev_x + player.w <= wall.rect.left:

                    player.rect.x = wall.rect.x - player.w
                    player.stopXVel()

                if player.prev_x >= wall.rect.right:

                    player.rect.x = wall.rect.x + wall.w
                    player.stopXVel()

                if player.prev_y + player.h <= wall.rect.top:

                    player.rect.y = wall.rect.y - player.h
                    player.stopYVel()

                if player.prev_y >= wall.rect.bottom:

                    player.rect.y = wall.rect.y + wall.h
                    player.stopYVel()

def assignTextures():

    for hitbox in collision_boxes:
        for texture in textures:

            if hitbox.uuid == texture.uuid:

                texture.rect.center = hitbox.rect.center

                break
            
    for player in players:
        for texture in textures:

            if player.uuid == texture.uuid:

                texture.rect.center = player.rect.center

                break
    

def updateAll():

    all_sprites.update()
    collisionHandling()
    assignTextures()



screen_width = 500
screen_height = 500
screen = pygame.display.set_mode((screen_width, screen_height))
bg_color = (255, 255, 255)
directory = os.path.dirname(os.path.realpath("hitbox testing.py")) + "/"
img_dir = directory + "images/"
end_shell = False
total_frames = 0
zoom = 50

pygame.init()

pygame.display.set_caption("Hitbox Testing")

fps = 120
clock = pygame.time.Clock()

all_sprites = pygame.sprite.Group()
textures = pygame.sprite.Group()
collision_boxes = pygame.sprite.Group()

players = pygame.sprite.Group()
walls = pygame.sprite.Group()

player = Player(0, 0, 50, 50, 0, 0, 100, 100, "player/", 0)
wall = Wall(250, 250, 100, 100, 250, 250, 100, 100, "wall/", 1)

#textures.add(())
players.add((player))
walls.add((wall))
all_sprites.add((players, walls, textures))



while not end_shell:

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            end_shell = True

    screen.fill(bg_color)
    
    updateAll()

    all_sprites.draw(screen)

    total_frames += 1

    pygame.display.update()
    clock.tick(fps)

pygame.quit()
