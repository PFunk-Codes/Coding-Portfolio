###################
### Max Provolt ###
###    SNAKE    ###
###  A venture  ###
###################

import pygame
import random as r

class Entity(pygame.sprite.Sprite):

    def update_position(self):

        self.rect.x += self.xVel
        self.rect.y += self.yVel


class SnakeHead(Entity):

    def __init__(self, x, y, width, height, color, player):

        pygame.sprite.Sprite.__init__(self)

        self.width = width
        self.height = height

        self.color = color

        self.image = pygame.Surface([self.width, self.height])
        self.image.fill(self.color)

        self.rect = self.image.get_rect()

        self.rect.x = x
        self.rect.y = y

        self.xVel = 0
        self.yVel = 0

        self.length = 3

        self.score = 0

        self.player = player

    def bounds(self):

        if self.rect.left < 0 or self.rect.right > screen_width or self.rect.top < 0 or self.rect.bottom > screen_height:

            print(str(self.score))
            self.kill()

    def generate_tail(self):

        if self.xVel != 0 or self.yVel != 0:

            body = SnakeBody(self.rect.x, self.rect.y, zoom, zoom, (11, 102, 35), self.length)
            allSprites.add(body)
            snakeBody.add(body)

    def events(self):

        self.keys = pygame.key.get_pressed()

        self.movements()

    def movements(self):
        
        if self.player == "p2":

            if self.keys[pygame.K_RIGHT] and self.xVel != (-1 * zoom):
                self.xVel = 1 * zoom
                self.yVel = 0
            if self.keys[pygame.K_LEFT] and self.xVel != (1 * zoom):
                self.xVel = -1 * zoom
                self.yVel = 0

            if self.keys[pygame.K_UP] and self.yVel != (1 * zoom):
                self.yVel = -1 * zoom
                self.xVel = 0
            if self.keys[pygame.K_DOWN] and self.yVel != (-1 * zoom):
                self.yVel = 1 * zoom
                self.xVel = 0
                
        elif self.player == "p1":

            if self.keys[pygame.K_d] and self.xVel != (-1 * zoom):
                self.xVel = 1 * zoom
                self.yVel = 0
            if self.keys[pygame.K_a] and self.xVel != (1 * zoom):
                self.xVel = -1 * zoom
                self.yVel = 0

            if self.keys[pygame.K_w] and self.yVel != (1 * zoom):
                self.yVel = -1 * zoom
                self.xVel = 0
            if self.keys[pygame.K_s] and self.yVel != (-1 * zoom):
                self.yVel = 1 * zoom
                self.xVel = 0

    def update(self):

        self.bounds()
        self.events()
        self.generate_tail()
        self.update_position()
        
            

class SnakeBody(Entity):

    def __init__(self, x, y, width, height, color, lifetime):

        pygame.sprite.Sprite.__init__(self)

        self.width = width
        self.height = height

        self.color = color

        self.image = pygame.Surface([self.width, self.height])
        self.image.fill(self.color)

        self.rect = self.image.get_rect()

        self.rect.x = x
        self.rect.y = y

        self.lifetime = lifetime

    def is_kill(self):

        self.lifetime -= 1

        if self.lifetime == 0:
            self.kill()

    def update(self):

        self.is_kill()


class Berry(Entity):

    def __init__(self, x, y, width, height, color):

        pygame.sprite.Sprite.__init__(self)

        self.width = width
        self.height = height

        self.color = color

        self.image = pygame.Surface([self.width, self.height])
        self.image.fill(self.color)

        self.rect = self.image.get_rect()

        self.rect.x = x
        self.rect.y = y


class Button(Entity):

    def __init__(self, x, y, width, height, color, text):

        pygame.sprite.Sprite.__init__(self)

        self.width = width
        self.height = height

        self.color = color

        self.image = pygame.Surface([self.width, self.height])

        self.rect = self.image.get_rect(center = (x, y))

        self.font = pygame.font.Font("freesansbold.ttf", 20)
        self.text = self.font.render(text, True, (0, 0, 0))
        self.textrect = self.text.get_rect(center = self.image.get_rect().center)
        self.rect.center = (screen_width / 2, screen_height / 2)
        self.image.blit(self.text, self.textrect)


def collisions():

    for body in snakeBody:
        for head in snakeHead:

            if pygame.sprite.collide_rect(body, head):

                print(str(head.score))
                head.kill()

    for head in snakeHead:
        for berry in berries:

            if pygame.sprite.collide_rect(head, berry):

                berry.kill()
                head.length += berry_power
                head.score += 1

                for body in snakeBody:

                    body.lifetime += berry_power

    for berry in berries:
        for body in snakeBody:

            if pygame.sprite.collide_rect(body, berry):

                berry.kill()

##    for head1 in snakeHead:
##        for head2 in snakeHead:
##
##            if pygame.sprite.collide_rect(head1, head2):
##                if head1.player == head2.player:
##
##                    head1.kill()
##                    head2.kill()

def random_berries():

    if len(berries.sprites()) == 0:

        berry = Berry(zoom * (r.randint(1, grid_size[0] - 1)), zoom * (r.randint(1, grid_size[1] - 1)), zoom, zoom, (255, 0, 0))

        for body in snakeBody:

            if pygame.sprite.collide_rect(body, berry):

                berry.kill()
                random_berries()

        allSprites.add(berry)
        berries.add(berry)

def update_all():

    allSprites.update()
    collisions()
    random_berries()

    

end_shell = False
total_frames = 0

grid_size = [20, 20]
berry_power = 5
zoom = 30
score = 0

screen_width = grid_size[0] * zoom
screen_height = grid_size[1] * zoom
screen = pygame.display.set_mode((int(screen_width), int(screen_height)))
bg_color = (255, 255, 255)
gamestate = "title_screen"

pygame.init()

pygame.display.set_caption("Snake")

fps = 9
clock = pygame.time.Clock()

allSprites = pygame.sprite.Group()
snakeBody = pygame.sprite.Group()
snakeHead = pygame.sprite.Group()
berries = pygame.sprite.Group()
buttons = pygame.sprite.Group()

button = Button(100, 100, 50, 50, (20, 20, 20), "Bruh")
allSprites.add(button)
buttons.add(button)

snakep1 = SnakeHead(zoom, zoom, zoom, zoom, (255, 255, 0), "p1")
snakep2 = SnakeHead((screen_width - (2 * zoom)), zoom, zoom, zoom, (0, 255, 255), "p2")
allSprites.add((snakep1, snakep2))
snakeHead.add((snakep1, snakep2))

while not end_shell:

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            end_shell = True

    screen.fill(bg_color)

    update_all()

    allSprites.draw(screen)

    total_frames += 1

    pygame.display.update()
    clock.tick(fps)

pygame.quit()


