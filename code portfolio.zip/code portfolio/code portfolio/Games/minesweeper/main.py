################################
#         MINESWEEPER          #
#    Designed - Max Provolt    #
#   Assistance - Adam Wolfe    #
#                              #
#      Minesweeper is a        #
#  functionally simple game.   #
#  using the written methods   #
#  of Adam Wolfe to create a   #
#  grid, I have fashioned a    #
#primitive form of minesweeper.#
################################


# SETUP
# --- import modules (pygame, random, math)
# --- initialize pygame
# --- screen
# --- title
# --- clock

# Classes
# Tile --- used for making tiles in the game
# Must have position, size
# > 

# > 

# Button -- used for making buttons

# Functions

# Groups
# --- all_sprites = used to hold all sprites
# --- all_tiles = used to hold all tiles

# Main
# --- settings
# ------- level number
# ------- start the timer
# ------- create all instances of sprites
# ------- create all widgets (display stats & time)
# --- game loop
# ------- event handling (keyboard, mouse)
# ------- logic (collision detection)
# ------- drawing (clear the screen, redraw the sprites)
# ------- updates (pygame.display.update, clock.tick(fps))


# Current Project
#
# Write clearSpace() to be more robust
#
# Must be expanded to clear a region bounded by neighbored tiles


import pygame, os, math, random, time

class Tile(pygame.sprite.Sprite): # A controllable character. The main character, as well as multiplayer characters.

    def __init__(self, x, y, w, h, grid_x, grid_y, file): #Initialize the sprite's assets and functions. Runs once,
        pygame.sprite.Sprite.__init__(self)
        
        #Size
        self.w = w
        self.h = h

        #Appearance
        self.color = (255, 255, 255)
        self.file = file

        #Surface ***
        self.image = pygame.Surface([self.w, self.h])
        self.image_directory = ""
        self.image_name1 = "grid.png"
        self.image_name2 = "grid_highlight.png"

        #Position of the Sprite
        self.x = x
        self.y = y
        self.grid_x = grid_x
        self.grid_y = grid_y

        #Rect ***
        self.rect = self.image.get_rect()
        self.rect.x = self.x
        self.rect.y = self.y

        #Neighbors

        self.neighbors = 0

        #Booleans
        self.is_bomb = False
        self.is_clear = False
        self.is_left_click = False
        self.is_right_click = False

    def spriteRender(self): 

        #Load Image
        
        self.image = pygame.transform.scale((pygame.image.load(self.image_directory)), (int(self.w), int(self.h)))

    def checkForMouse(self):

        mouse = pygame.mouse.get_pos()
        click = pygame.mouse.get_pressed()

        if self.x + self.w > mouse[0] > self.x:
            if self.y + self.h > mouse[1] > self.y:
                self.image_directory = directory + self.file + self.image_name2

                if click[0] == 1 and not self.is_left_click:
                    if not self.is_left_click:
                        self.actionLeft()
                    self.is_left_click = True
                elif click[0] == 0:
                    self.is_left_click = False
                    
                if click[2] == 1:
                    if not self.is_right_click:
                        self.actionRight()
                    self.is_right_click = True
                elif click[2] == 0:
                    self.is_right_click = False
                    
            else:
                self.image_directory = directory + self.file + self.image_name1
        else:
            self.image_directory = directory + self.file + self.image_name1

    def actionLeft(self):

        if not self.is_bomb:
            if not self.image_name1 == "flag.png":

                generateImages(self)
                if self.neighbors == 0:
                    clearSpace(self)
                

        if self.is_bomb:
            if not self.image_name1 == "flag.png":
                print("OOF")

                time.sleep(1)

                pygame.quit()

    def actionRight(self):

        if self.image_name2 == "grid_highlight.png":
            self.image_name1 = "flag.png"
            self.image_name2 = "flag_highlight.png"
        elif self.image_name2 == "flag_highlight.png":
            self.image_name1 = "grid.png"
            self.image_name2 = "grid_highlight.png"

    def events(self):

        self.checkForMouse()

    def update(self):
    
        self.events()
        self.spriteRender()



def generateTiles():
    allTiles = pygame.sprite.Group()

    x, y = 0, 0
    grid_x, grid_y = 1, 1
    w, h = screen_width / tiles_per_side, screen_height / tiles_per_side

    for row in range(tiles_per_side):
        for column in range(tiles_per_side):

            tile = Tile(x, y, w, h, grid_x, grid_y, "images/")
            allTiles.add(tile)
            x += w
            grid_x += 1
            
        x = 0
        grid_x = 1
        y += h
        grid_y += 1

    return allTiles

def generateBombs():

    bomb_tiles = []

    while len(bomb_tiles) < tiles_per_side * 2:
        bomb_tile = ((random.randint(1, tiles_per_side)), (random.randint(1, tiles_per_side)))

        if not bomb_tile in bomb_tiles:
            bomb_tiles.append(bomb_tile)

    print(bomb_tiles)

    for tile in allTiles:
        if (tile.grid_x, tile.grid_y) in bomb_tiles:
            
            tile.is_bomb = True
            tile.add(allBombs)

def generateNumbers():

    for tile in allTiles:
        for bomb in allBombs:
            if not tile in allBombs:
                if tile.grid_x >= bomb.grid_x - 1 and tile.grid_x <= bomb.grid_x + 1:
                    if tile.grid_y >= bomb.grid_y - 1 and tile.grid_y <= bomb.grid_y + 1:

                        tile.neighbors += 1

def clearSpace(sprite): 

    is_iterating = True
    start = True

    while is_iterating:
        for test_tile in allTiles:

            if not start:

                is_iterating = False

                for origin_tile in allTiles:
                    if origin_tile.is_clear and origin_tile.neighbors == 0:
                        if test_tile.grid_x >= origin_tile.grid_x - 1 and test_tile.grid_x <= origin_tile.grid_x + 1:
                            if test_tile.grid_y >= origin_tile.grid_y - 1 and test_tile.grid_y <= origin_tile.grid_y + 1:

                                generateImages(test_tile)
                                test_tile.is_clear = True
                                is_iterating = True

            else:

                if test_tile.grid_x >= sprite.grid_x - 1 and test_tile.grid_x <= sprite.grid_x + 1:
                    if test_tile.grid_y >= sprite.grid_y - 1 and test_tile.grid_y <= sprite.grid_y + 1:

                        generateImages(test_tile)
                        test_tile.is_clear = True

        start = False

def generateImages(sprite):

    if sprite.neighbors == 0:
        sprite.image_name1 = "0.png"
        sprite.image_name2 = "0_highlight.png"
    if sprite.neighbors == 1:
        sprite.image_name1 = "1.png"
        sprite.image_name2 = "1_highlight.png"
    if sprite.neighbors == 2:
        sprite.image_name1 = "2.png"
        sprite.image_name2 = "2_highlight.png"
    if sprite.neighbors == 3:
        sprite.image_name1 = "3.png"
        sprite.image_name2 = "3_highlight.png"
    if sprite.neighbors == 4:
        sprite.image_name1 = "4.png"
        sprite.image_name2 = "4_highlight.png"
    if sprite.neighbors == 5:
        sprite.image_name1 = "5.png"
        sprite.image_name2 = "5_highlight.png"
    if sprite.neighbors == 6:
        sprite.image_name1 = "6.png"
        sprite.image_name2 = "6_highlight.png"
    if sprite.neighbors == 7:
        sprite.image_name1 = "7.png"
        sprite.image_name2 = "7_highlight.png"
    if sprite.neighbors == 8:
        sprite.image_name1 = "8.png"
        sprite.image_name2 = "8_highlight.png"
            

def update_all():

  allSprites.update()
  


#constants
screen_width = 500 #
screen_height = 500 #change these if needed until better solution arises
bg_color = (128, 128, 128)
screen = pygame.display.set_mode([screen_width, screen_height])
directory = os.path.dirname(os.path.realpath("game 2.py")) + "/"
end_shell = False
tiles_per_side = 20
total_frames = 0

#MAC directory - "/Users/maximilian.provolt/Desktop/Code/Python/megamax/"
#PI directory - "/home/pi/Desktop/Python/megamax/"

pygame.init()

pygame.display.set_caption("|<>| MINESWEEPER |<>|")

#clock
fps = 40
clock = pygame.time.Clock()

#groups
allSprites = pygame.sprite.Group()
allTiles = generateTiles()
allSprites.add(allTiles)
allBombs = pygame.sprite.Group()

generateBombs()
generateNumbers()

while not end_shell:

  #Event Handling
  for event in pygame.event.get():
    if event.type==pygame.QUIT:
      end_shell = True

  #Clear the Screen
  screen.fill(bg_color)

  #Updates
  update_all()

  #Drawing
  allSprites.draw(screen)

  #Next frame
  total_frames += 1
  
  pygame.display.update()
  clock.tick(fps)

pygame.quit()
