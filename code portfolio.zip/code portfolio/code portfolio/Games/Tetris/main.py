import pygame, time, os, random

class Entity(pygame.sprite.Sprite):

    def stop_xVel(self): #simple function stopping the x velocity.

        self.xVel = 0

    def stop_yVel(self): #simple function stopping the y velocity.

        self.yVel = 0

    def stop_vel(self): #simple function calling stop_xVel() and stop_yVel() to stop all movement.

        self.stop_xVel()
        self.stop_yVel()
    
    def update_position(self): #function that adds the calculated change of position by other functions to the actual position of the sprite.

        self.rect.x += self.xVel
        self.rect.y += self.yVel

    def store_position(self): #function that preserves the previous position of the sprite before calculated changes are factored in.

        self.prev_xPos = self.rect.x
        self.prev_yPos = self.rect.y

    def bounds(self):

        if self.rect.top < 0:
            self.rect.top = 0
            self.stop_yVel()
        elif self.rect.bottom > screen_height:
            self.rect.bottom = screen_height
            self.stop_yVel()

        if self.rect.left < 0:
            self.rect.left = 0
            self.stop_xVel()
        elif self.rect.right > screen_width:
            self.rect.right = screen_width
            self.stop_xVel()
        

class Tile(Entity):

    def __init__(self, x, y, w, h, img):

        pygame.sprite.Sprite.__init__(self)

        self.width = w
        self.height = h

        self.img = img
        self.image = pygame.Surface([self.width, self.height])
        self.image_name = img_dir + self.img

        self.rect = self.image.get_rect()

        self.rect.x = x
        self.rect.y = y

        self.xVel = 0
        self.yVel = 0

        self.speed = 5

        self.landed = False

    def load_image(self):

        self.image = pygame.transform.scale((pygame.image.load(self.image_name)), (self.width, self.height))

    def fall_loop(self):

        if total_frames % 10 == 0:

            self.rect.y += 28

    def update(self):

        self.store_position()
        self.fall_loop()
        self.update_position()
        self.bounds()
        self.load_image()


class TileMoveable(Tile):

    def movements(self):

        if self.keys[pygame.K_RIGHT]:
            self.xVel = self.speed
        if self.keys[pygame.K_LEFT]:
            self.xVel = -self.speed
            
        if self.keys[pygame.K_UP]:
            self.yVel = -self.speed
        if self.keys[pygame.K_DOWN]:
            self.yVel = self.speed

        if not self.keys[pygame.K_RIGHT] and not self.keys[pygame.K_LEFT]:
            self.xVel = 0
        if not self.keys[pygame.K_UP] and not self.keys[pygame.K_DOWN]:
            self.yVel = 0

    def events(self):

        self.keys = pygame.key.get_pressed()

        self.movements()

    def update(self):

        self.store_position()
        self.update_position()
        self.events()
        self.bounds()
        self.load_image()


class Barrier(Entity):

    def __init__(self, x, y, w, h, img):

        pygame.sprite.Sprite.__init__(self)

        self.width = w
        self.height = h

        self.img = img
        self.image = pygame.Surface([self.width, self.height])
        self.image_name = img_dir + self.img

        self.rect = self.image.get_rect()

        self.rect.x = x
        self.rect.y = y

    def load_image(self):

        self.image = pygame.transform.scale((pygame.image.load(self.image_name)), (self.width, self.height))

    def update(self):

        self.load_image()


def collisions():

    for tile in tiles:
        for mTile in moveableTiles:

            if pygame.sprite.collide_rect(tile, mTile):

                mTile.rect.x = mTile.prev_xPos
                mTile.rect.y = mTile.prev_yPos

    for tile in allTiles:
        for barrier in barriers:

            if pygame.sprite.collide_rect(tile, barrier):

                tile.rect.x = mTile.prev_xPos
                tile.rect.y = mTile.prev_yPos


            

def update_all():

    allSprites.update()
    collisions()


directory = os.path.dirname(os.path.realpath("level mapping.py")) + "/"
img_dir = directory + "images/"
end_shell = False
total_frames = 0

screen_width = 1000
screen_height = 700
screen = pygame.display.set_mode((screen_width, screen_height))
bg_color = (255, 255, 255)

pygame.init()

pygame.display.set_caption("Tetris v1.0.0 | Max Provolt")

fps = 120
clock = pygame.time.Clock()

tile1 = Tile(100, 100, 31, 31, "Red.png")
tile2 = Tile(128, 100, 31, 31, "Red.png")
tile3 = Tile(100, 128, 31, 31, "Red.png")
tile4 = Tile(128, 128, 31, 31, "Red.png")
tileM = TileMoveable(200, 200, 31, 31, "Blue.png")
wall1 = Barrier(0, 0, 10, 500, "Barrier.png")


allSprites = pygame.sprite.Group()
tiles = pygame.sprite.Group()
moveableTiles = pygame.sprite.Group()
allTiles = pygame.sprite.Group()
activePiece = pygame.sprite.Group()
barriers = pygame.sprite.Group()

allSprites.add((tile1, tile2, tile3, tile4, tileM, wall1))
tiles.add((tile1, tile2, tile3, tile4))
moveableTiles.add(tileM)
allTiles.add((tile1, tile2, tile3, tile4, tileM))
barriers.add(wall1)


while not end_shell:

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            end_shell = True

    screen.fill(bg_color)

    update_all()

    allSprites.draw(screen)

    total_frames += 1

    pygame.display.update()
    clock.tick(fps)

pygame.quit()
