This Repository is filled with my personal projects that are at varying degrees of completion in the past 2 years.

All of these I give at least partial credit to my coding mentor and fellow enthusiast, Adam Wolfe.
His insight into the methodology and vocabulary of python and other compiled languages like C has been instrumental.
He is also a fantastic teacher, coach, personality, inspiration, and friend.

I'm going to go through each of these in order, and describe them in as much detail as I can. Some of them I can't remember too well.

Please, if anyone you know has the urge to edit these files and make something more out of them, by all means, send them this. I have a copy on my hard drive, it'll be fine. I'd love to see where they take my ideas.

For your reading pleasure, I recommend having this file and the folder with all the documents on your screen at the same time. It makes it easier to read as you go. But you don't have to take my advice, I guess...



> Games
	> hitbox experiment

This was a fairly recent project, actually. I made this about 3 weeks ago, and it was a proof of concept for separating the logical part of the game character with the visual part in pygame.
Pygame sprites are Surface type objects in memory, where collisions and image rendering are both handled. So, I created two sprites with different surfaces and used a UUID to bind their positions together in a parent function.
I think it worked pretty well. I describe it a little bit better in the README in that folder, and there is also a version of the .py file with notes and without, for ease of editing.

	> maze master

This one was fun. I made this about 4 months ago as also a proof of concept for an idea I had to create customizable level generation. Since the idea relies on a grid pattern to work, I figured mazes were a good genre to explore.
The game has a player you control, maze walls that you can't go through, and a yellow goal. When the player touches the goal, the game generates the new level and you play that. What's cool is that you can edit the file with
levels and create your own. There's a README in there, too, but basically, I used nested for loops to go character by character and create a sprite at a specified location. Reading the code for it is probably easier... All the code
for the level generation is in generate_level(scale). That's the main selling point, though; otherwise, you just solve mazes until the levels run out. Was extremely satisfying to get the kinks out and make a presentable game.

	> megamax

This one goes back the farthest. I made this at least 1 year and 3 months ago, probably more. This is also the project that I spent the most amount of time on for a while. I was planning on making a full game, with title screen, menus,
a story, fight mechanics, the works. I soon found out I lack the dedication to do something so large by myself. I usually need a team to celebrate with when we get progress to have any motivation after about 2 weeks.
Anyways, in this game, I for the first time programmed an image management system, gravity, projectile firing, multiple players, sprite animation, collision detection, and even sound playback (although now it is defunct).
I am proud of the idea that this represents, and I am also fond of all of the memories of technical challenges that I overcame creating this. However, I have moved on to other projects now.

	> minesweeper

Exactly what it sounds like. I made minesweeper in 4 hours one night when I was bored at my dad's place. I was surprised to see it work my first try, albeit extremely buggily. Usually, I make a mistake somewhere that doesn't even
let anything appear in the pygame window, but it somehow functioned mainly as intended first try. I fixed some of the bugs, but there are still times where the game will freeze for no reason. If this happens, just close the shell.
I intend to attempt to remake the game to be less buggy, and also potentially add some semblance of menu functionality. But for now, have my very glitchy and unstable version of minesweeper.

	> Tetris

I don't know why I included this. It is not tetris at all, in any way. However, I did create some of the mechanics that goes into constructing tetris. For instance, even though the game runs at a high clock speed, the tetrominoes
only move on a specified proportion of frames. Also, I differentiated between a controllable object and a falling object. I don't know how to put it all together yet, though. I'm sorry for disappointing you, the reader, that you can't
play tetris. I understand.

> Math Stuff
	> Factors
		> Factors Calculator

Simple peice of code that will calculate the factors of a given number. Also, I got fancy with tkinter, so the entire UI is in a window. Can be optimized, but I don't see the need to do it unless I make a website or something.

		> GCF Calculator

First finds the factors of two input numbers, then compares the two lists and finds the greatest in value. Fairly simple as well, but actually more useful than you think in math class.

		> pi estimator

This needs a little bit of mathematical explaining. There is a youtube channel called standupmaths run by a guy called Matt Parker, and every March 14th he makes a pi day video where he calculates pi in weird ways. Last year's was
using random number coprime probabilities. If you generate pairs of random numbers, see if they are coprime or not, then divide the total coprime pairs by the total pairs, you get a number.
the square root of (6 divided by that number) is approximately pi. Don't ask me why or how, but it is. And the way Matt Parker showed this was by rolling a ton of dice and writing down the tally of coprime pairs by hand.
Obviously, for entertainment's sake. He could have written a js script to do it for him in a tenth of a second. That's what I did here. I combined the other two projects in this folder with the math in the video
and made this. It actually works surprisingly well; sometimes, you can get up to 4 decimals or more of precision. Just be careful about putting in too large of a number, because it can get to be a long wait.
I also added in a progress notifier, where it will print out every 20000 pairs to let you know where it is. It's quite nice.

	> Julia Sets
		
This entire folder is my favorite thing I've done in python. If you know much about complex numbers, or been on youtube in 2014, you've probably heard of the mandelbrot set. Essentially, it is an iteration of a function with
complex numbers (a + bi), and whether or not the result of the iteration explodes to infinity or stays finite is what determines whether or not the respective number is in the set. It is hard to explain, but it is much more
interesting to look at. It happens to be a fractal, a geometric shape with infinite complexity and recursive behavior. If you zoom in far enough into the set, you will see the set reappear. And you can zoom into the same point on the
miniature set, and find it again. My version does not have zooming capabilities, because I used text to represent it. However, if you go to an online generator, you can zoom in yourself and see what happens. I made a few different
copies of my original code to experiment with different values and ideas. I recommend looking at Mandelbrot gradient.py first, however, because I actually managed to program multiple layers of the set into one generation.
It really highlights the patterns behind the set, not just the set itself. Also, try increasing the variable img_res at the top of the screen, and decreasing the font size of python's IDLE. The default is what I found for a 1080p
screen at a font size of 7. However, if you use a more epic gamer screen, then you might be able to make this higher. 

	> Prime Generator

A prime number generator. You tell it where to stop, and it'll go. That's pretty much it.



Thank you for reading through this.