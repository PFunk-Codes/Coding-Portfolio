import math
import cmath

print("The mandelbrot set is a visual representation of the iteration of the function z^2+c.\nIt takes an imaginary number as c and 0 as z, and will find whether or not this iterative process is unbounded.\n")

cycle_str = "-"
img_res = 225
calc_res = 84

a = -2
b = 2

def testMandelbrot(c, res):

    z = 0
    thresh = res

    for x in range(res):

        try:

            z = z**2 + c

        except ValueError:

            print("not a number")
            break

        except:

            print("error")
            break
        
        if math.sqrt(((z.real)**2)+(z.imag)**2) >= 2:

            thresh = x + 1
            break

    return thresh




print(str(calc_res))

for y in range(img_res):
    for x in range(img_res):

        result = 0

        if math.sqrt((a**2)+(b**2)) <= 2:

            result = testMandelbrot(complex(a, b), calc_res)

        if result == calc_res:
            cycle_str += "█"
        elif result >= (calc_res / 6):
            cycle_str += "#"
        elif result >= (calc_res / 10):
            cycle_str += "%"
        elif result >= (calc_res / 15):
            cycle_str += "+"
        elif result >= (calc_res / 18):
            cycle_str += "•"
        elif result >= (calc_res / 24):
            cycle_str += "-"
        else:
            cycle_str += " "
            

        a += (1 / img_res * 4)

    b -= (1 / img_res * 4)
    a = -2
    print(cycle_str)
    cycle_str = "|"
    

        
