

def factors(value):
    out = ""
    if value.isnumeric(): #Tests if value is a numeric string. If it is zero, then value is a number, since the previous try: statement succeeded. If intTest is 1, then the except: statement ran, and value is not a number. This is to prevent EOF errors from occurring when the computer tries to divide strings.
        value = int(value)
        if value <= 2: #This statement merely checks if the number is less than or equal to two. It's pointless to run the code on numbers like this, so I exclude them immediately.
            print("Please insert a number greater than 2.")
        else:
            for x in range(int(value / 2)): #Loops for half the amount of value. Calculating for the numbers over half is pointless, since those numbers will never give whole number quotients.
                if value % (x + 1) == 0: #Tests if the remainder of value and x+1 is 0. If it is true, then x is a factor of value, since it evenly divides with value. +1 is necessary since x starts at 0, which returns an error upon first iteration.
                    out = out + str(x + 1) + ", " #Adds x in for: loop to out. Notice the ", " string at the end; if this was not added, then out would result in all the numbers squished together unintelligibly. You must add spaces in out to make the numbers clear.
            return out + str(int(value)) #Finally, returns the factors of value.
    else:
        print("Please insert a number.")

def gcf(entry_1, entry_2):

    entry_1 = entry_1.split(", ")
    entry_2 = entry_2.split(", ")
    gcf = 1

    print(entry_1)
    print(entry_2)

    if entry_1 == "PRIME" or entry_2 == "PRIME":
        return "COPRIME"
    
    else:
        for value_1 in entry_1:
            for value_2 in entry_2:
                if value_1 == value_2:
                    gcf = str(value_1)

        if gcf != "1":
            return gcf
        else:
            return "COPRIME"

while True:
    print(gcf(factors(input("Value 1: ")), factors(input("Value 2: "))))
    print("")
