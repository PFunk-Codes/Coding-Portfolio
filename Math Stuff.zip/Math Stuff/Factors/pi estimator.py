from random import *
from math import *
from time import *

coprime = 0
total = 0

def factors(value):
    out = ""
    if value.isnumeric(): #Tests if value is a numeric string. If it is zero, then value is a number, since the previous try: statement succeeded. If intTest is 1, then the except: statement ran, and value is not a number. This is to prevent EOF errors from occurring when the computer tries to divide strings.
        value = int(value)
        if value < 2: #This statement merely checks if the number is less than or equal to two. It's pointless to run the code on numbers like this, so I exclude them immediately.
            print("Please insert a number greater than or equal to 2.")
        else:
            for x in range(int(value / 2)): #Loops for half the amount of value. Calculating for the numbers over half is pointless, since those numbers will never give whole number quotients.
                if value % (x + 1) == 0: #Tests if the remainder of value and x+1 is 0. If it is true, then x is a factor of value, since it evenly divides with value. +1 is necessary since x starts at 0, which returns an error upon first iteration.
                    out = out + str(x + 1) + ", " #Adds x in for: loop to out. Notice the ", " string at the end; if this was not added, then out would result in all the numbers squished together unintelligibly. You must add spaces in out to make the numbers clear.
            return out + str(int(value)) #Finally, returns the factors of value.
    else:
        print("Please insert a number.")

def gcf(entry_1, entry_2):

    entry_1 = entry_1.split(", ")
    entry_2 = entry_2.split(", ")
    gcf = 1

    if entry_1 == "PRIME" or entry_2 == "PRIME":
        return "COPRIME"
    
    else:
        for value_1 in entry_1:
            for value_2 in entry_2:
                if value_1 == value_2:
                    gcf = str(value_1)

        if gcf != "1":
            return gcf
        else:
            return "COPRIME"

def increment(value):

    global coprime
    global total

    if value == "COPRIME":
        coprime += 1
    total += 1

def calculate_π(accuracy):

    start_time = time()

    for x in range(int(accuracy)):

        value_1 = str(randint(2, 1000))
        value_2 = str(randint(2, 1000))

        result = gcf(factors(value_1), factors(value_2))
        increment(result)

        if x % 20000 == 0:
            print(str(x) + "...")

    end_time = time()

    try:
        final = str((sqrt(6/(coprime/total))))
    except ZeroDivisionError:
        return "Undefined: divide by zero error" #If, somehow, every single number was not coprime, this equation is undefined. So, we add in an exception.
    return "Estimation: " + final + "\nTime Elapsed: " + str(end_time - start_time) + " seconds" #Each integer pair takes approximately 0.00014 seconds to calculate

print("This code uses random integers and whether they are coprime or not to calculate π! Just state how many pairs of integers to simulate to get a better and better approximation of π. BEWARE: Using a number too high will lead to excessive calculation times. Keep the number under about 100,000 for results under 15 seconds.")

while True:

    accuracy = input("Accuracy: ")
    print(calculate_π(accuracy) + "\n")
    coprime = 0
    total = 0
    
    
