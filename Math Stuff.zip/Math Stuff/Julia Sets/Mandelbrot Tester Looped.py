import math
import cmath

print("The mandelbrot set is a visual representation of the iteration of the function z^2+c.\nIt takes an imaginary number as c and 0 as z, and will find whether or not this iterative process is unbounded.\n")

cycle_str = "-"
img_res = 201
calc_res = 1

a = -2
b = 2

def testMandelbrot(c, res):

    z = 0

    try:
        
        passed = True

        for x in range(res):

            try:

                z = z**2 + c

            except OverflowError:

                print("too large for me")
                passed = False
                break

            except ValueError:

                print("not a number")
                passed = False
                break

            except:

                print("error")
                passed = False
                break

            
            if math.sqrt(((z.real)**2)+(z.imag)**2) >= 2:

                passed = False
                break

        if passed:
            return True
        if not passed:
            return False

    except ValueError:

        print("Not a number")


for x in range(15):

    print(str(calc_res))

    for y in range(img_res):
        for x in range(img_res):

            result = False

            if math.sqrt((a**2)+(b**2)) <= 2:

                result = testMandelbrot(complex(a, b), calc_res)

            if result:
                cycle_str += "█"
            elif not result:
                cycle_str += " "
                

            a += (1 / img_res * 4)

        b -= (1 / img_res * 4)
        a = -2
        print(cycle_str)
        cycle_str = "|"

    calc_res *= 2
    a = -2
    b = 2
    

        
